# fps_monitor.py

import time
import threading
import ctypes
from ctypes import wintypes, byref
import win32api
import win32con
import win32process
import psutil

class FPSMonitor:
    def __init__(self):
        self.fps = 0
        self.frame_count = 0
        self.last_time = time.time()
        self.running = True
        self.game_pid = None
        self.game_name = None
        
        # Windows API для мониторинга
        self.psapi = ctypes.WinDLL('psapi.dll')
        self.user32 = ctypes.WinDLL('user32.dll')
        
        # Список игровых процессов для мониторинга
        self.game_processes = [
            'cs2.exe', 'csgo.exe', 'dota2.exe', 'hl2.exe',  # Steam игры
            'valorant.exe', 'leagueclient.exe',             # Riot игры
            'overwatch.exe', 'battle.net.exe',              # Blizzard
            'minecraft.exe', 'javaw.exe',                   # Minecraft
            'gta5.exe', 'rdr2.exe',                         # Rockstar
            'fortnite.exe', 'epicgameslauncher.exe',        # Epic Games
            'steam.exe', 'origin.exe', 'uplay.exe'          # Лаунчеры
        ]
        
        # Запуск мониторинга
        self.start_monitoring()
    
    def find_game_process(self):
        """Поиск игрового процесса"""
        try:
            for proc in psutil.process_iter(['pid', 'name']):
                try:
                    proc_name = proc.info['name'].lower()
                    for game_name in self.game_processes:
                        if game_name in proc_name:
                            self.game_pid = proc.info['pid']
                            self.game_name = proc.info['name']
                            print(f"Найден игровой процесс: {self.game_name} (PID: {self.game_pid})")
                            return True
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except Exception as e:
            print(f"Ошибка поиска игрового процесса: {e}")
        
        return False
    
    def get_window_fps(self):
        """Получение FPS через Windows API (упрощенный метод)"""
        if not self.game_pid:
            return 0
        
        try:
            # Получаем дескриптор окна по PID
            def enum_windows_callback(hwnd, lParam):
                if self.user32.IsWindowVisible(hwnd):
                    pid = wintypes.DWORD()
                    self.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                    if pid.value == self.game_pid:
                        lParam.append(hwnd)
                return True
            
            windows = []
            enum_func = ctypes.WINFUNCTYPE(
                ctypes.c_bool, 
                ctypes.POINTER(ctypes.c_int), 
                ctypes.POINTER(ctypes.c_int)
            )
            callback = enum_func(enum_windows_callback)
            self.user32.EnumWindows(callback, windows)
            
            if not windows:
                return 0
                
            hwnd = windows[0]
            
            # Проверяем, активно ли окно
            if self.user32.GetForegroundWindow() == hwnd:
                # Если окно активно, используем более точный метод
                current_time = time.time()
                self.frame_count += 1
                
                # Считаем FPS за последнюю секунду
                if current_time - self.last_time >= 1.0:
                    self.fps = self.frame_count
                    self.frame_count = 0
                    self.last_time = current_time
                
                return self.fps
            else:
                # Если окно не активно, возвращаем последнее известное значение
                return self.fps
                
        except Exception as e:
            print(f"Ошибка получения FPS: {e}")
            return 0
    
    def monitor_fps(self):
        """Мониторинг FPS в отдельном потоке"""
        while self.running:
            try:
                # Ищем игровой процесс если еще не нашли
                if not self.game_pid:
                    self.find_game_process()
                    time.sleep(2)  # Ждем перед повторной попыткой
                    continue
                
                # Проверяем, существует ли еще процесс
                try:
                    psutil.Process(self.game_pid)
                except psutil.NoSuchProcess:
                    self.game_pid = None
                    self.game_name = None
                    self.fps = 0
                    time.sleep(2)
                    continue
                
                # Получаем FPS
                current_fps = self.get_window_fps()
                
                # Если не удалось получить FPS, пробуем найти другой процесс
                if current_fps == 0:
                    time.sleep(1)
                    continue
                
                time.sleep(0.05)  # Частое обновление для точного FPS
                
            except Exception as e:
                print(f"Ошибка в потоке мониторинга FPS: {e}")
                time.sleep(1)
    
    def start_monitoring(self):
        """Запуск мониторинга"""
        self.monitor_thread = threading.Thread(target=self.monitor_fps, daemon=True)
        self.monitor_thread.start()
    
    def get_fps(self):
        """Получение текущего FPS"""
        return self.fps
    
    def stop(self):
        """Остановка мониторинга"""
        self.running = False
        if hasattr(self, 'monitor_thread'):
            self.monitor_thread.join(timeout=1)

# Альтернативный метод для DirectX через NVIDIA/AMD API
class GPUFPSMonitor:
    """Мониторинг FPS через GPU (если доступно)"""
    
    def __init__(self):
        self.fps = 0
        self.last_frame_time = time.time()
        self.frame_times = []
        self.running = True
        
        # Пробуем использовать NVIDIA API если доступно
        self.nvapi_available = self._init_nvapi()
        
        if self.nvapi_available:
            print("Используется NVIDIA API для мониторинга FPS")
        else:
            print("Используется программный мониторинг FPS")
        
        self.start_monitoring()
    
    def _init_nvapi(self):
        """Инициализация NVIDIA API"""
        try:
            # Попытка загрузить NVAPI
            nvapi = ctypes.WinDLL('nvapi64.dll')
            return True
        except:
            return False
    
    def monitor_gpu_fps(self):
        """Мониторинг FPS через GPU"""
        while self.running:
            try:
                current_time = time.time()
                
                # Простой метод подсчета кадров
                # В реальной реализации здесь будет вызов GPU API
                
                # Имитируем получение данных от GPU
                # Для реального использования нужны: NVAPI, ADL, или DirectX API
                self.frame_times.append(current_time)
                
                # Оставляем только последние 60 кадров
                if len(self.frame_times) > 60:
                    self.frame_times.pop(0)
                
                # Рассчитываем FPS на основе времени между кадрами
                if len(self.frame_times) >= 2:
                    time_diff = self.frame_times[-1] - self.frame_times[0]
                    if time_diff > 0:
                        self.fps = len(self.frame_times) / time_diff
                    else:
                        self.fps = 0
                else:
                    self.fps = 0
                
                time.sleep(0.016)  # ~60 FPS обновление
                
            except Exception as e:
                print(f"Ошибка мониторинга GPU FPS: {e}")
                time.sleep(1)
    
    def start_monitoring(self):
        """Запуск мониторинга"""
        self.monitor_thread = threading.Thread(target=self.monitor_gpu_fps, daemon=True)
        self.monitor_thread.start()
    
    def get_fps(self):
        """Получение FPS"""
        return int(self.fps) if self.fps > 0 else 0
    
    def stop(self):
        """Остановка"""
        self.running = False

# Фасад для выбора лучшего метода
class RealFPSMonitor:
    def __init__(self):
        self.fps_monitor = None
        
        # Пробуем разные методы мониторинга
        try:
            # Сначала пробуем Windows API метод
            self.fps_monitor = FPSMonitor()
            print("Активирован мониторинг FPS через Windows API")
        except Exception as e:
            print(f"Windows API мониторинг недоступен: {e}")
            try:
                # Затем пробуем GPU метод
                self.fps_monitor = GPUFPSMonitor()
                print("Активирован мониторинг FPS через GPU")
            except Exception as e2:
                print(f"GPU мониторинг недоступен: {e2}")
                self.fps_monitor = None
    
    def get_fps(self):
        """Получение FPS"""
        if self.fps_monitor:
            return self.fps_monitor.get_fps()
        return 0  # Возвращаем 0 если мониторинг недоступен
    
    def stop(self):
        """Остановка мониторинга"""
        if self.fps_monitor:
            self.fps_monitor.stop()

# Синглтон для глобального доступа
_fps_monitor_instance = None

def get_fps_monitor():
    """Получение экземпляра монитора FPS"""
    global _fps_monitor_instance
    if _fps_monitor_instance is None:
        _fps_monitor_instance = RealFPSMonitor()
    return _fps_monitor_instance

def get_current_fps():
    """Получение текущего FPS"""
    monitor = get_fps_monitor()
    return monitor.get_fps()