# graph.py

import tkinter as tk
import collections
import time
import psutil
import threading
from utils import get_gpu_info

class GraphManager:
    def __init__(self, app=None):
        self.app = app
        self.graphs = {}
        self.data_buffers = {}
        self.update_interval = 1  # секунда
        self.running = True
        
        # Инициализация буферов данных
        self.init_data_buffers()
        
        # Запуск сбора данных (откладываем до создания графиков)
        self.collection_thread = None
    
    def init_data_buffers(self):
        """Инициализация буферов данных для графиков"""
        buffer_size = 60  # 60 точек = 1 минута данных
        
        self.data_buffers = {
            'cpu': collections.deque(maxlen=buffer_size),
            'ram': collections.deque(maxlen=buffer_size),
            'gpu_load': collections.deque(maxlen=buffer_size),
            'gpu_mem': collections.deque(maxlen=buffer_size),
            'net_sent': collections.deque(maxlen=buffer_size),
            'net_recv': collections.deque(maxlen=buffer_size),
            'temp_cpu': collections.deque(maxlen=buffer_size),
            'temp_gpu': collections.deque(maxlen=buffer_size)
        }
        
        # Инициализация нулевыми значениями
        for buffer in self.data_buffers.values():
            for _ in range(buffer_size):
                buffer.append(0)
    
    def start_data_collection(self):
        """Запуск сбора данных в отдельном потоке"""
        if self.collection_thread and self.collection_thread.is_alive():
            return
            
        def collect_data():
            last_net_io = psutil.net_io_counters()
            last_time = time.time()
            
            while self.running:
                try:
                    current_time = time.time()
                    time_diff = current_time - last_time
                    
                    # CPU
                    cpu_percent = psutil.cpu_percent(interval=0.1)
                    self.data_buffers['cpu'].append(cpu_percent)
                    
                    # RAM
                    ram = psutil.virtual_memory()
                    self.data_buffers['ram'].append(ram.percent)
                    
                    # GPU
                    try:
                        gpu_info = get_gpu_info()
                        if gpu_info:
                            gpu = gpu_info[0]
                            # Преобразуем "12.3%" в 12.3
                            load_str = gpu.get('Load', '0%').replace('%', '')
                            mem_str = gpu.get('Memory Percent', '0%').replace('%', '')
                            
                            self.data_buffers['gpu_load'].append(float(load_str))
                            self.data_buffers['gpu_mem'].append(float(mem_str))
                            
                            # Температура GPU
                            temp_str = gpu.get('Temperature', '0°C').replace('°C', '')
                            try:
                                self.data_buffers['temp_gpu'].append(float(temp_str))
                            except ValueError:
                                self.data_buffers['temp_gpu'].append(0)
                        else:
                            self.data_buffers['gpu_load'].append(0)
                            self.data_buffers['gpu_mem'].append(0)
                            self.data_buffers['temp_gpu'].append(0)
                    except Exception:
                        self.data_buffers['gpu_load'].append(0)
                        self.data_buffers['gpu_mem'].append(0)
                        self.data_buffers['temp_gpu'].append(0)
                    
                    # Сеть (рассчитываем скорость)
                    current_net_io = psutil.net_io_counters()
                    if time_diff > 0:
                        sent_speed = (current_net_io.bytes_sent - last_net_io.bytes_sent) / time_diff / 1024  # KB/s
                        recv_speed = (current_net_io.bytes_recv - last_net_io.bytes_recv) / time_diff / 1024  # KB/s
                    else:
                        sent_speed = 0
                        recv_speed = 0
                    
                    self.data_buffers['net_sent'].append(sent_speed)
                    self.data_buffers['net_recv'].append(recv_speed)
                    
                    # Температура CPU
                    try:
                        if hasattr(psutil, "sensors_temperatures"):
                            temps = psutil.sensors_temperatures()
                            if temps and 'coretemp' in temps:
                                cpu_temp = temps['coretemp'][0].current
                                self.data_buffers['temp_cpu'].append(cpu_temp)
                            else:
                                self.data_buffers['temp_cpu'].append(0)
                        else:
                            self.data_buffers['temp_cpu'].append(0)
                    except Exception:
                        self.data_buffers['temp_cpu'].append(0)
                    
                    last_net_io = current_net_io
                    last_time = current_time
                    
                except Exception as e:
                    print(f"Ошибка сбора данных графиков: {e}")
                
                # Обновляем графики в главном потоке
                if self.app and hasattr(self.app, 'running') and self.app.running:
                    try:
                        self.app.root.after(100, self.update_all_graphs)
                    except Exception:
                        pass
                
                time.sleep(self.update_interval)
        
        self.collection_thread = threading.Thread(target=collect_data, daemon=True)
        self.collection_thread.start()
    
    def create_graph_tab(self, notebook):
        """Создание вкладки с графиками в 2 колонки"""
        graphs_frame = tk.Frame(notebook, bg="#282a36")
        notebook.add(graphs_frame, text="📈 ГРАФИКИ")
        
        # Контейнер с прокруткой
        container = tk.Frame(graphs_frame, bg="#282a36")
        container.pack(fill="both", expand=True)
        
        canvas = tk.Canvas(container, bg="#282a36", highlightthickness=0)
        scrollbar = tk.Scrollbar(container, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="#282a36")
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True, padx=(10, 0))
        scrollbar.pack(side="right", fill="y")
        
        # Сетка для графиков (2 колонки)
        graph_grid = tk.Frame(scrollable_frame, bg="#282a36")
        graph_grid.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Создаем графики
        self._create_all_graphs(graph_grid)
        
        # Запускаем сбор данных после создания графиков
        self.start_data_collection()
        
        # Начальная отрисовка графиков
        if self.app and hasattr(self.app, 'root'):
            self.app.root.after(500, self.update_all_graphs)
        
        return graphs_frame
    
    def _create_all_graphs(self, parent):
        """Создание всех графиков"""
        graphs_config = [
            ("⚡ CPU", "cpu", "#ff5555", "%", 0, 100),
            ("🧠 RAM", "ram", "#50fa7b", "%", 0, 100),
            ("🎮 GPU Загр.", "gpu_load", "#ffb86c", "%", 0, 100),
            ("🎮 GPU Пам.", "gpu_mem", "#bd93f9", "%", 0, 100),
            ("📤 Сеть Отпр.", "net_sent", "#8be9fd", "KB/s", 0, 1024),
            ("📥 Сеть Прием", "net_recv", "#ff79c6", "KB/s", 0, 1024),
            ("🌡️ CPU", "temp_cpu", "#ff5555", "°C", 0, 100),
            ("🌡️ GPU", "temp_gpu", "#ffb86c", "°C", 0, 100)
        ]
        
        # Создаем сетку 4x2 (4 строки, 2 колонки)
        for i, (title, data_key, color, y_label, y_min, y_max) in enumerate(graphs_config):
            row = i // 2
            col = i % 2
            
            # Фрейм для графика
            graph_frame = tk.Frame(parent, bg="#282a36", relief="sunken", bd=1)
            graph_frame.grid(row=row, column=col, padx=5, pady=5, sticky="nsew")
            
            # Настройка весов для растягивания
            parent.rowconfigure(row, weight=1)
            parent.columnconfigure(col, weight=1)
            
            # Заголовок графика
            title_frame = tk.Frame(graph_frame, bg="#282a36")
            title_frame.pack(fill="x", padx=5, pady=5)
            
            tk.Label(
                title_frame,
                text=f"▌ {title}",
                bg="#282a36",
                fg=color,
                font=("Courier New", 11, "bold"),
                anchor="w"
            ).pack(side="left")
            
            # Текущее значение
            value_label = tk.Label(
                title_frame,
                text="0",
                bg="#282a36",
                fg="#f8f8f2",
                font=("Courier New", 10)
            )
            value_label.pack(side="right", padx=5)
            
            # Холст для графика
            graph_canvas = tk.Canvas(
                graph_frame,
                bg="#282a36",
                height=100,
                highlightthickness=0
            )
            graph_canvas.pack(fill="both", expand=True, padx=8, pady=(0, 8))
            
            # Сохраняем ссылки
            self.graphs[data_key] = {
                'canvas': graph_canvas,
                'color': color,
                'title': title,
                'y_label': y_label,
                'y_min': y_min,
                'y_max': y_max,
                'value_label': value_label,
                'frame': graph_frame
            }
    
    def draw_graph(self, graph_key):
        """Отрисовка графика"""
        if graph_key not in self.graphs:
            return
        
        graph_info = self.graphs[graph_key]
        canvas = graph_info['canvas']
        color = graph_info['color']
        y_min = graph_info['y_min']
        y_max = graph_info['y_max']
        
        # Очищаем холст
        canvas.delete("all")
        
        # Размеры холста
        width = canvas.winfo_width()
        height = canvas.winfo_height()
        
        if width <= 1 or height <= 1:
            # Если холст еще не отрисован, планируем перерисовку позже
            if self.app and hasattr(self.app, 'root'):
                self.app.root.after(100, lambda: self.draw_graph(graph_key))
            return
        
        # Параметры графика
        padding = 15
        graph_width = width - 2 * padding
        graph_height = height - 2 * padding
        
        # Данные
        data = list(self.data_buffers.get(graph_key, []))
        if not data:
            return
        
        # Отрисовка сетки
        self._draw_grid(canvas, width, height, padding, graph_height, y_min, y_max)
        
        # Отрисовка графика
        if len(data) > 1:
            points = []
            
            for i, value in enumerate(data):
                x = padding + (i / (len(data) - 1)) * graph_width
                
                # Нормализация значения
                if y_max > y_min:
                    normalized = max(0, min(1, (value - y_min) / (y_max - y_min)))
                else:
                    normalized = 0
                
                y = height - padding - normalized * graph_height
                points.append((x, y))
            
            # Отрисовка линии
            if len(points) > 1:
                for i in range(len(points) - 1):
                    x1, y1 = points[i]
                    x2, y2 = points[i + 1]
                    canvas.create_line(x1, y1, x2, y2, fill=color, width=2)
            
            # Отрисовка последней точки
            if points:
                last_x, last_y = points[-1]
                canvas.create_oval(last_x-3, last_y-3, last_x+3, last_y+3, 
                                 fill=color, outline=color)
        
        # Обновляем текущее значение
        if data and graph_info.get('value_label'):
            current_value = data[-1]
            if graph_key in ['net_sent', 'net_recv']:
                # Форматируем скорость сети
                if current_value < 1024:
                    value_text = f"{current_value:.1f} KB/s"
                elif current_value < 1024*1024:
                    value_text = f"{current_value/1024:.1f} MB/s"
                else:
                    value_text = f"{current_value/(1024*1024):.1f} GB/s"
            elif graph_key in ['temp_cpu', 'temp_gpu']:
                value_text = f"{current_value:.1f}°C"
            else:
                value_text = f"{current_value:.1f}%"
            
            graph_info['value_label'].config(text=value_text)
    
    def _draw_grid(self, canvas, width, height, padding, graph_height, y_min, y_max):
        """Отрисовка сетки графика"""
        # Вертикальные линии (время)
        for i in range(6):
            x = padding + (i / 5) * (width - 2 * padding)
            canvas.create_line(x, padding, x, height - padding, 
                             fill="#44475a", width=1)
        
        # Горизонтальные линии (значения)
        for i in range(5):
            y = padding + (i / 4) * graph_height
            canvas.create_line(padding, y, width - padding, y, 
                             fill="#44475a", width=1)
        
        # Подписи оси Y (только минимальное и максимальное значение)
        if y_max > y_min:
            # Верхнее значение
            canvas.create_text(padding - 5, padding, text=f"{y_max:.0f}", 
                             fill="#6272a4", font=("Courier New", 7), 
                             anchor="e")
            # Нижнее значение
            canvas.create_text(padding - 5, height - padding, text=f"{y_min:.0f}", 
                             fill="#6272a4", font=("Courier New", 7), 
                             anchor="e")
    
    def update_all_graphs(self):
        """Обновление всех графиков"""
        if not self.running:
            return
            
        try:
            for graph_key in list(self.graphs.keys()):
                self.draw_graph(graph_key)
        except Exception as e:
            print(f"Ошибка обновления графиков: {e}")
        
        # Планируем следующее обновление
        if (self.running and self.app and 
            hasattr(self.app, 'running') and self.app.running and
            hasattr(self.app, 'root')):
            self.app.root.after(1000, self.update_all_graphs)
    
    def stop(self):
        """Остановка сбора данных"""
        self.running = False
        if self.collection_thread and self.collection_thread.is_alive():
            self.collection_thread.join(timeout=1)

# Функция для обратной совместимости
def create_graphs_tab(notebook, app=None):
    """Создание вкладки с графиками"""
    graph_manager = GraphManager(app)
    return graph_manager.create_graph_tab(notebook), graph_manager