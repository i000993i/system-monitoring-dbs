# styles.py

from tkinter import ttk

def apply_styles(root):
    style = ttk.Style()
    style.theme_use("clam")
    
    # Основные цвета темы Dracula
    bg_color = "#282a36"
    fg_color = "#f8f8f2"
    selection_color = "#44475a"
    
    # Конфигурация стилей для пиксельного дизайна
    style.configure("Pixel.TFrame", 
                   background=bg_color, 
                   relief="flat", 
                   borderwidth=1)
    
    style.configure("Pixel.TLabel", 
                   background=bg_color, 
                   foreground=fg_color,
                   font=("Courier New", 11))
    
    style.configure("Pixel.TButton", 
                   background="#44475a", 
                   foreground=fg_color,
                   font=("Courier New", 11), 
                   borderwidth=1, 
                   relief="raised",
                   padding=5)
    
    style.map("Pixel.TButton",
              background=[('active', "#6272a4"), ('pressed', "#44475a")],
              foreground=[('active', fg_color), ('pressed', fg_color)],
              relief=[('pressed', 'sunken'), ('active', 'raised')])
    
    # Настройка стиля вкладок
    style.configure("Pixel.TNotebook", 
                   background=bg_color, 
                   borderwidth=0,
                   tabmargins=[2, 2, 0, 0])
    
    style.configure("Pixel.TNotebook.Tab",
                   background=bg_color,
                   foreground="#6272a4",
                   padding=[15, 5],
                   font=("Courier New", 11),
                   borderwidth=1)
    
    style.map("Pixel.TNotebook.Tab",
              background=[("selected", selection_color), ("active", "#6272a4")],
              foreground=[("selected", "#ff79c6"), ("active", "#ff79c6")])
    
    # Стиль для полос прокрутки
    style.configure("Vertical.TScrollbar",
                   background=bg_color,
                   troughcolor=selection_color,
                   bordercolor=bg_color,
                   arrowcolor=fg_color,
                   relief="flat")
    
    style.configure("Horizontal.TScrollbar",
                   background=bg_color,
                   troughcolor=selection_color,
                   bordercolor=bg_color,
                   arrowcolor=fg_color,
                   relief="flat")
    
    # Стиль для Combobox
    style.configure("TCombobox",
                   fieldbackground=selection_color,
                   background=selection_color,
                   foreground=fg_color,
                   selectbackground="#6272a4",
                   selectforeground=fg_color,
                   insertcolor=fg_color,
                   font=("Courier New", 11))
    
    style.map("TCombobox",
              fieldbackground=[('readonly', selection_color)],
              selectbackground=[('readonly', '#6272a4')])
    
    # Стиль для Entry
    style.configure("TEntry",
                   fieldbackground=selection_color,
                   foreground=fg_color,
                   insertcolor=fg_color,
                   font=("Courier New", 11))
    
    # Установка стиля по умолчанию для некоторых виджетов
    root.configure(bg=bg_color)
    
    return style