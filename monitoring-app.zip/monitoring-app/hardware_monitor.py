# hardware_monitor.py
# Автономная система мониторинга оборудования через WMI и встроенные методы

import threading
import time
from typing import Dict, List, Optional, Any

class HardwareMonitor:
    def __init__(self):
        self.data = {}
        self.running = True
        self.last_update = 0
        self.update_interval = 2.0  # секунды
        self.lock = threading.Lock()
        
        # Запуск потока обновления
        self.start_monitoring()
    
    def get_hardware_data(self) -> Dict[str, Any]:
        """Получение данных оборудования через доступные методы"""
        data = {
            'cpu': {},
            'gpu': [],
            'ram': {},
            'disks': [],
            'fans': []
        }
        
        try:
            # Основная информация через psutil и другие встроенные методы
            self._get_basic_cpu_data(data)
            self._get_basic_gpu_data(data)
            self._get_basic_ram_data(data)
            self._get_basic_disk_data(data)
            
            # Пробуем получить дополнительную информацию через доступные API
            try:
                self._try_wmi_data(data)
            except Exception:
                pass
            
        except Exception as e:
            print(f"Ошибка получения данных оборудования: {e}")
        
        return data
    
    def _get_basic_cpu_data(self, data: Dict[str, Any]):
        """Получение базовой информации о CPU"""
        try:
            import psutil
            
            # Загрузка CPU
            cpu_percent = psutil.cpu_percent(interval=0.1, percpu=True)
            cpu_total = psutil.cpu_percent(interval=0.1)
            
            data['cpu']['load_total'] = cpu_total
            data['cpu']['load_per_core'] = cpu_percent
            
            # Количество ядер
            data['cpu']['physical_cores'] = psutil.cpu_count(logical=False) or 1
            data['cpu']['logical_cores'] = psutil.cpu_count(logical=True) or 1
            
            # Частота
            freq = psutil.cpu_freq()
            if freq:
                data['cpu']['freq_current'] = freq.current if hasattr(freq, 'current') else 0
                data['cpu']['freq_min'] = freq.min if hasattr(freq, 'min') else 0
                data['cpu']['freq_max'] = freq.max if hasattr(freq, 'max') else 0
            
            # Температура (если доступно)
            if hasattr(psutil, "sensors_temperatures"):
                sensors = psutil.sensors_temperatures()
                if sensors:
                    cpu_temps = []
                    for name, entries in sensors.items():
                        if 'core' in name.lower() or 'cpu' in name.lower() or 'package' in name.lower():
                            for entry in entries:
                                cpu_temps.append(entry.current)
                    
                    if cpu_temps:
                        data['cpu']['temp_avg'] = sum(cpu_temps) / len(cpu_temps)
                        data['cpu']['temp_max'] = max(cpu_temps)
                        data['cpu']['temp_min'] = min(cpu_temps)
            
        except Exception as e:
            print(f"Ошибка получения данных CPU: {e}")
    
    def _get_basic_gpu_data(self, data: Dict[str, Any]):
        """Получение базовой информации о GPU"""
        try:
            # Пробуем использовать GPUtil для NVIDIA/AMD
            try:
                import GPUtil
                gpus = GPUtil.getGPUs()
                
                for i, gpu in enumerate(gpus):
                    gpu_data = {
                        'id': i,
                        'name': gpu.name,
                        'load': gpu.load * 100,  # Проценты
                        'memory_total': gpu.memoryTotal,
                        'memory_used': gpu.memoryUsed,
                        'memory_free': gpu.memoryFree,
                        'memory_percent': (gpu.memoryUsed / gpu.memoryTotal) * 100,
                        'temperature': gpu.temperature,
                        'driver': gpu.driver if hasattr(gpu, 'driver') else 'N/A'
                    }
                    data['gpu'].append(gpu_data)
                    
            except ImportError:
                # GPUtil не установлен
                pass
            except Exception:
                # Ошибка GPUtil
                pass
            
            # Если GPU не найдены через GPUtil, пробуем другие методы
            if not data['gpu']:
                self._try_detect_gpu_alternative(data)
                
        except Exception as e:
            print(f"Ошибка получения данных GPU: {e}")
    
    def _try_detect_gpu_alternative(self, data: Dict[str, Any]):
        """Альтернативные методы обнаружения GPU"""
        try:
            # Пробуем через WMI
            try:
                import wmi
                import pythoncom
                
                pythoncom.CoInitialize()
                wmi_conn = wmi.WMI()
                
                # Ищем GPU в WMI
                for adapter in wmi_conn.Win32_VideoController():
                    if adapter.Name:
                        gpu_data = {
                            'id': len(data['gpu']),
                            'name': adapter.Name,
                            'load': 0,  # Недоступно через WMI
                            'memory_total': adapter.AdapterRAM // (1024*1024) if adapter.AdapterRAM else 0,
                            'driver_version': adapter.DriverVersion if hasattr(adapter, 'DriverVersion') else 'N/A'
                        }
                        data['gpu'].append(gpu_data)
                        
            except Exception:
                pass
                
        except Exception:
            pass
    
    def _get_basic_ram_data(self, data: Dict[str, Any]):
        """Получение базовой информации о RAM"""
        try:
            import psutil
            
            ram = psutil.virtual_memory()
            
            data['ram']['total'] = ram.total
            data['ram']['available'] = ram.available
            data['ram']['used'] = ram.used
            data['ram']['percent'] = ram.percent
            data['ram']['free'] = ram.free
            
        except Exception as e:
            print(f"Ошибка получения данных RAM: {e}")
    
    def _get_basic_disk_data(self, data: Dict[str, Any]):
        """Получение базовой информации о дисках"""
        try:
            import psutil
            
            for i, partition in enumerate(psutil.disk_partitions()):
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    
                    disk_data = {
                        'id': i,
                        'device': partition.device,
                        'mountpoint': partition.mountpoint,
                        'fstype': partition.fstype,
                        'total': usage.total,
                        'used': usage.used,
                        'free': usage.free,
                        'percent': usage.percent
                    }
                    
                    # Пробуем получить температуру диска (если доступно)
                    if hasattr(psutil, "sensors_temperatures"):
                        sensors = psutil.sensors_temperatures()
                        if sensors:
                            for name, entries in sensors.items():
                                if 'disk' in name.lower() or 'hdd' in name.lower() or 'ssd' in name.lower():
                                    for entry in entries:
                                        disk_data['temperature'] = entry.current
                                        break
                    
                    data['disks'].append(disk_data)
                    
                except Exception:
                    continue
                    
        except Exception as e:
            print(f"Ошибка получения данных дисков: {e}")
    
    def _try_wmi_data(self, data: Dict[str, Any]):
        """Попытка получения дополнительных данных через WMI"""
        try:
            import wmi
            import pythoncom
            
            pythoncom.CoInitialize()
            wmi_conn = wmi.WMI()
            
            # Температуры через WMI
            try:
                temperatures = {}
                
                # Пробуем разные пространства имен WMI
                namespaces = [
                    "root\\WMI",  # Для некоторых датчиков
                    "root\\cimv2",  # Стандартное
                    "root\\OpenHardwareMonitor"  # Если OHM установлен
                ]
                
                for namespace in namespaces:
                    try:
                        wmi_temp = wmi.WMI(namespace=namespace)
                        
                        # Ищем классы с температурой
                        for wmi_class in wmi_temp.classes:
                            class_name = str(wmi_class).lower()
                            if 'temperature' in class_name or 'thermal' in class_name:
                                try:
                                    instances = wmi_class.instances()
                                    for instance in instances:
                                        if hasattr(instance, 'CurrentTemperature') or hasattr(instance, 'Temperature'):
                                            temp_value = getattr(instance, 'CurrentTemperature', 
                                                               getattr(instance, 'Temperature', 0))
                                            if temp_value:
                                                # Конвертируем в градусы Цельсия (WMI часто в десятых градусах Кельвина)
                                                temp_c = float(temp_value) / 10.0 - 273.15 if temp_value > 100 else float(temp_value)
                                                name = getattr(instance, 'Name', 
                                                              getattr(instance, 'InstanceName', f"Sensor_{len(temperatures)}"))
                                                temperatures[name] = temp_c
                                except Exception:
                                    continue
                    except Exception:
                        continue
                
                # Добавляем найденные температуры
                if temperatures:
                    for name, temp in temperatures.items():
                        if 'cpu' in name.lower() or 'core' in name.lower() or 'package' in name.lower():
                            if 'cpu_temps' not in data['cpu']:
                                data['cpu']['cpu_temps'] = {}
                            data['cpu']['cpu_temps'][name] = temp
                        elif 'gpu' in name.lower() or 'graphics' in name.lower():
                            for gpu in data['gpu']:
                                gpu['temperature'] = temp
                                break
                
            except Exception:
                pass
            
            # Вентиляторы через WMI
            try:
                fans = []
                
                for fan in wmi_conn.Win32_Fan():
                    fan_data = {
                        'name': fan.Name if hasattr(fan, 'Name') else 'Fan',
                        'speed': fan.DesiredSpeed if hasattr(fan, 'DesiredSpeed') else 0,
                        'status': fan.Status if hasattr(fan, 'Status') else 'Unknown'
                    }
                    fans.append(fan_data)
                
                if fans:
                    data['fans'] = fans
                    
            except Exception:
                pass
            
            # Дополнительная информация о CPU
            try:
                for processor in wmi_conn.Win32_Processor():
                    if not data['cpu'].get('name'):
                        data['cpu']['name'] = processor.Name
                    if not data['cpu'].get('manufacturer'):
                        data['cpu']['manufacturer'] = processor.Manufacturer
                    if not data['cpu'].get('max_clock'):
                        data['cpu']['max_clock'] = processor.MaxClockSpeed if hasattr(processor, 'MaxClockSpeed') else 0
                    if not data['cpu'].get('l2_cache'):
                        data['cpu']['l2_cache'] = processor.L2CacheSize if hasattr(processor, 'L2CacheSize') else 0
                    if not data['cpu'].get('l3_cache'):
                        data['cpu']['l3_cache'] = processor.L3CacheSize if hasattr(processor, 'L3CacheSize') else 0
                    break  # Берем только первый процессор
                    
            except Exception:
                pass
            
        except Exception:
            # WMI не доступен, игнорируем
            pass
    
    def start_monitoring(self):
        """Запуск потока мониторинга"""
        def monitor_loop():
            while self.running:
                try:
                    current_time = time.time()
                    
                    if current_time - self.last_update >= self.update_interval:
                        with self.lock:
                            self.data = self.get_hardware_data()
                            self.last_update = current_time
                    
                    time.sleep(0.5)  # Короткая пауза
                    
                except Exception as e:
                    time.sleep(2)
        
        self.monitor_thread = threading.Thread(target=monitor_loop, daemon=True)
        self.monitor_thread.start()
    
    def get_cpu_temperature(self) -> Optional[float]:
        """Получение температуры CPU"""
        with self.lock:
            cpu_data = self.data.get('cpu', {})
            
            # Пробуем получить среднюю температуру
            if 'temp_avg' in cpu_data:
                return cpu_data['temp_avg']
            
            # Пробуем получить температуры ядер
            if 'cpu_temps' in cpu_data:
                temps = list(cpu_data['cpu_temps'].values())
                if temps:
                    return sum(temps) / len(temps)
            
            # Ищем любую температуру CPU
            for key, value in cpu_data.items():
                if isinstance(value, (int, float)) and 'temp' in key.lower():
                    return value
            
            return None
    
    def get_gpu_temperature(self, gpu_index: int = 0) -> Optional[float]:
        """Получение температуры GPU"""
        with self.lock:
            gpus = self.data.get('gpu', [])
            
            if gpu_index < len(gpus):
                gpu = gpus[gpu_index]
                if 'temperature' in gpu and gpu['temperature']:
                    return gpu['temperature']
            
            return None
    
    def get_gpu_load(self, gpu_index: int = 0) -> Optional[float]:
        """Получение загрузки GPU"""
        with self.lock:
            gpus = self.data.get('gpu', [])
            
            if gpu_index < len(gpus):
                gpu = gpus[gpu_index]
                if 'load' in gpu:
                    return gpu['load']
            
            return None
    
    def get_all_temperatures(self) -> Dict[str, float]:
        """Получение всех температур"""
        temps = {}
        
        with self.lock:
            # CPU температуры
            cpu_temp = self.get_cpu_temperature()
            if cpu_temp:
                temps['cpu'] = cpu_temp
            
            # GPU температуры
            gpus = self.data.get('gpu', [])
            for i, gpu in enumerate(gpus):
                if 'temperature' in gpu and gpu['temperature']:
                    temps[f'gpu_{i}'] = gpu['temperature']
            
            # Температуры дисков
            for i, disk in enumerate(self.data.get('disks', [])):
                if 'temperature' in disk and disk['temperature']:
                    temps[f'disk_{i}'] = disk['temperature']
        
        return temps
    
    def get_detailed_cpu_info(self) -> Dict[str, Any]:
        """Получение детальной информации о CPU"""
        with self.lock:
            result = self.data.get('cpu', {}).copy()
            
            # Форматируем данные для отображения
            formatted = {}
            
            # Основная информация
            if 'name' in result:
                formatted['Модель'] = result['name']
            if 'manufacturer' in result:
                formatted['Производитель'] = result['manufacturer']
            
            if 'physical_cores' in result:
                formatted['Физические ядра'] = result['physical_cores']
            if 'logical_cores' in result:
                formatted['Логические ядра'] = result['logical_cores']
            
            if 'load_total' in result:
                formatted['Загрузка'] = f"{result['load_total']:.1f}%"
            
            if 'freq_current' in result:
                formatted['Частота'] = f"{result['freq_current']:.0f} МГц"
            if 'max_clock' in result:
                formatted['Макс. частота'] = f"{result['max_clock']:.0f} МГц"
            
            if 'l2_cache' in result and result['l2_cache']:
                formatted['Кэш L2'] = f"{result['l2_cache']} КБ"
            if 'l3_cache' in result and result['l3_cache']:
                formatted['Кэш L3'] = f"{result['l3_cache']} КБ"
            
            # Температуры
            cpu_temp = self.get_cpu_temperature()
            if cpu_temp:
                formatted['Температура'] = f"{cpu_temp:.1f}°C"
            
            return formatted
    
    def get_detailed_gpu_info(self, gpu_index: int = 0) -> Dict[str, Any]:
        """Получение детальной информации о GPU"""
        with self.lock:
            gpus = self.data.get('gpu', [])
            
            if gpu_index < len(gpus):
                gpu = gpus[gpu_index].copy()
                
                # Форматируем данные для отображения
                formatted = {}
                
                if 'name' in gpu:
                    formatted['Модель'] = gpu['name']
                
                if 'load' in gpu:
                    formatted['Загрузка'] = f"{gpu['load']:.1f}%"
                
                if 'memory_total' in gpu:
                    formatted['Память'] = f"{gpu['memory_total']} МБ"
                
                if 'memory_used' in gpu and 'memory_total' in gpu:
                    mem_percent = (gpu['memory_used'] / gpu['memory_total']) * 100
                    formatted['Исп. памяти'] = f"{mem_percent:.1f}%"
                
                if 'temperature' in gpu and gpu['temperature']:
                    formatted['Температура'] = f"{gpu['temperature']:.1f}°C"
                
                if 'driver' in gpu:
                    formatted['Драйвер'] = gpu['driver']
                
                return formatted
            
            return {}
    
    def get_fan_speeds(self) -> List[Dict[str, Any]]:
        """Получение скоростей вентиляторов"""
        with self.lock:
            fans = self.data.get('fans', [])
            
            # Если нет данных о вентиляторах, создаем примерные
            if not fans:
                return [
                    {'name': 'CPU Fan', 'speed': 1200, 'type': 'cpu'},
                    {'name': 'Chassis Fan', 'speed': 800, 'type': 'case'}
                ]
            
            return fans
    
    def stop(self):
        """Остановка мониторинга"""
        self.running = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=2)

# Глобальный инстанс
_hardware_monitor_instance = None

def get_hardware_monitor():
    """Получение экземпляра монитора оборудования"""
    global _hardware_monitor_instance
    if _hardware_monitor_instance is None:
        _hardware_monitor_instance = HardwareMonitor()
    return _hardware_monitor_instance

# Удобные функции для быстрого доступа
def get_cpu_temperature():
    """Получение температуры CPU"""
    monitor = get_hardware_monitor()
    return monitor.get_cpu_temperature()

def get_gpu_temperature(gpu_index=0):
    """Получение температуры GPU"""
    monitor = get_hardware_monitor()
    return monitor.get_gpu_temperature(gpu_index)

def get_all_temperatures():
    """Получение всех температур"""
    monitor = get_hardware_monitor()
    return monitor.get_all_temperatures()

def get_detailed_cpu_info():
    """Получение детальной информации о CPU"""
    monitor = get_hardware_monitor()
    return monitor.get_detailed_cpu_info()

def get_detailed_gpu_info(gpu_index=0):
    """Получение детальной информации о GPU"""
    monitor = get_hardware_monitor()
    return monitor.get_detailed_gpu_info(gpu_index)

def get_fan_speeds():
    """Получение скоростей вентиляторов"""
    monitor = get_hardware_monitor()
    return monitor.get_fan_speeds()