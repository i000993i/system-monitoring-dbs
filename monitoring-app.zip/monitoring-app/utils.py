# utils.py

import psutil
import platform
import datetime
import time
import socket
import subprocess
import threading
from typing import Optional, Dict, Any, List
import GPUtil
from fps_monitor import get_current_fps as get_real_fps

class SystemMonitor:
    # Кэш для данных
    _cache = {}
    _cache_time = {}
    _cache_duration = 2  # секунды
    
    @staticmethod
    def get_cached(key, func, *args, **kwargs):
        """Получение данных с кэшированием"""
        current_time = time.time()
        
        # Проверяем, есть ли свечие данные в кэше
        if key in SystemMonitor._cache:
            cache_time = SystemMonitor._cache_time.get(key, 0)
            if current_time - cache_time < SystemMonitor._cache_duration:
                return SystemMonitor._cache[key]
        
        # Получаем новые данные
        try:
            result = func(*args, **kwargs)
            SystemMonitor._cache[key] = result
            SystemMonitor._cache_time[key] = current_time
            return result
        except Exception as e:
            # Возвращаем старые данные при ошибке
            if key in SystemMonitor._cache:
                return SystemMonitor._cache[key]
            return None
    
    @staticmethod
    def get_system_info() -> Dict[str, Any]:
        """Получение информации о системе"""
        key = "system_info"
        return SystemMonitor.get_cached(key, SystemMonitor._get_system_info_impl)
    
    @staticmethod
    def _get_system_info_impl() -> Dict[str, Any]:
        """Реализация получения информации о системе"""
        info = {}
        
        try:
            # ОС и версия
            info['OS'] = platform.system()
            info['Version'] = platform.version()
            info['Release'] = platform.release()
            
            # Архитектура
            info['Architecture'] = platform.machine()
            
            # Имя ПК
            info['Hostname'] = socket.gethostname()
            
            # Процессор
            info['Processor'] = platform.processor()
            
            # Время работы системы
            boot_time = datetime.datetime.fromtimestamp(psutil.boot_time())
            uptime = datetime.datetime.now() - boot_time
            info['Uptime'] = str(uptime).split('.')[0]
            
            # Память
            mem = psutil.virtual_memory()
            info['Memory'] = {
                'Total': SystemMonitor.format_bytes(mem.total),
                'Available': SystemMonitor.format_bytes(mem.available),
                'Used': SystemMonitor.format_bytes(mem.used),
                'Percent': f"{mem.percent}%"
            }
            
            # Диски
            disks = []
            for partition in psutil.disk_partitions():
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    disks.append({
                        'Device': partition.device,
                        'Mountpoint': partition.mountpoint,
                        'FSType': partition.fstype,
                        'Total': SystemMonitor.format_bytes(usage.total),
                        'Used': SystemMonitor.format_bytes(usage.used),
                        'Free': SystemMonitor.format_bytes(usage.free),
                        'Percent': f"{usage.percent:.1f}%"
                    })
                except Exception:
                    continue
            info['Disks'] = disks
            
            # Сеть
            net_io = psutil.net_io_counters()
            info['Network'] = {
                'Bytes Sent': SystemMonitor.format_bytes(net_io.bytes_sent),
                'Bytes Received': SystemMonitor.format_bytes(net_io.bytes_recv),
                'Packets Sent': net_io.packets_sent,
                'Packets Received': net_io.packets_recv
            }
            
        except Exception as e:
            print(f"Ошибка получения информации о системе: {e}")
        
        return info
    
    @staticmethod
    def get_cpu_info() -> Dict[str, Any]:
        """Получение информации о процессоре"""
        key = "cpu_info"
        return SystemMonitor.get_cached(key, SystemMonitor._get_cpu_info_impl)
    
    @staticmethod
    def _get_cpu_info_impl() -> Dict[str, Any]:
        """Реализация получения информации о процессоре"""
        info = {}
        
        try:
            # Загрузка CPU
            cpu_percent = psutil.cpu_percent(interval=0.1, percpu=True)
            cpu_total = psutil.cpu_percent(interval=0.1)
            
            info['Usage'] = {
                'Total': f"{cpu_total:.1f}%",
                'Per Core': [f"{percent:.1f}%" for percent in cpu_percent]
            }
            
            # Частота
            freq = psutil.cpu_freq()
            if freq:
                info['Frequency'] = {
                    'Current': f"{freq.current:.0f} МГц",
                    'Min': f"{freq.min:.0f} МГц",
                    'Max': f"{freq.max:.0f} МГц"
                }
            
            # Количество ядер
            info['Cores'] = {
                'Physical': psutil.cpu_count(logical=False) or 1,
                'Logical': psutil.cpu_count(logical=True) or 1
            }
            
        except Exception as e:
            print(f"Ошибка получения информации о CPU: {e}")
        
        return info
    
    @staticmethod
    def get_gpu_info() -> List[Dict[str, Any]]:
        """Получение информации о видеокартах"""
        key = "gpu_info"
        return SystemMonitor.get_cached(key, SystemMonitor._get_gpu_info_impl)
    
    @staticmethod
    def _get_gpu_info_impl() -> List[Dict[str, Any]]:
        """Реализация получения информации о видеокартах"""
        gpus = []
        
        try:
            # Используем GPUtil для NVIDIA/AMD карт
            for gpu in GPUtil.getGPUs():
                gpu_info = {
                    'Name': gpu.name,
                    'Load': f"{gpu.load * 100:.1f}%",
                    'Memory Total': f"{gpu.memoryTotal} MB",
                    'Memory Used': f"{gpu.memoryUsed} MB",
                    'Memory Free': f"{gpu.memoryFree} MB",
                    'Memory Percent': f"{(gpu.memoryUsed / gpu.memoryTotal) * 100:.1f}%",
                    'Temperature': f"{gpu.temperature:.1f}°C"
                }
                gpus.append(gpu_info)
            
        except Exception:
            # GPU не обнаружены или ошибка GPUtil
            pass
        
        return gpus
    
    @staticmethod
    def get_battery_info() -> Optional[Dict[str, Any]]:
        """Получение информации о батарее"""
        key = "battery_info"
        return SystemMonitor.get_cached(key, SystemMonitor._get_battery_info_impl)
    
    @staticmethod
    def _get_battery_info_impl() -> Optional[Dict[str, Any]]:
        """Реализация получения информации о батарее"""
        try:
            battery = psutil.sensors_battery()
            if battery:
                # Расчет оставшегося времени
                if battery.secsleft == psutil.POWER_TIME_UNLIMITED:
                    time_left = "Неограниченно (зарядка)"
                elif battery.secsleft == psutil.POWER_TIME_UNKNOWN:
                    time_left = "Неизвестно"
                else:
                    hours = battery.secsleft // 3600
                    minutes = (battery.secsleft % 3600) // 60
                    time_left = f"{hours:02d}:{minutes:02d}"
                
                # Определение цвета
                if battery.percent > 70:
                    color = "#00ff88"
                elif battery.percent > 30:
                    color = "#ffaa00"
                else:
                    color = "#ff5555"
                
                return {
                    'percent': battery.percent,
                    'plugged': battery.power_plugged,
                    'time_left': time_left,
                    'color': color,
                    'status': "Заряжается" if battery.power_plugged and battery.percent < 100 else 
                             "Заряжена" if battery.power_plugged and battery.percent >= 100 else 
                             "Разряжается"
                }
            else:
                # Для стационарных ПК
                return {
                    'percent': 100,
                    'plugged': True,
                    'time_left': "N/A",
                    'color': "#00ff88",
                    'status': "Питание от сети"
                }
                
        except Exception as e:
            return None
    
    @staticmethod
    def get_fps() -> Optional[Dict[str, Any]]:
        """Получение FPS"""
        # Используем новый монитор FPS из fps_monitor.py
        fps_value = get_real_fps()
        if fps_value > 0:
            color = "#00ff88" if fps_value > 60 else "#ffaa00" if fps_value > 30 else "#ff5555"
            status = "Отлично" if fps_value > 60 else "Хорошо" if fps_value > 30 else "Плохо"
        else:
            fps_value = 0
            color = "#888888"
            status = "Неактивен"
            
        return {
            'value': fps_value,
            'color': color,
            'status': status
        }
    
    @staticmethod
    def get_ping(host: str = "8.8.8.8") -> Optional[Dict[str, Any]]:
        """Получение пинга до указанного хоста"""
        key = f"ping_{host}"
        return SystemMonitor.get_cached(key, SystemMonitor._get_ping_impl, host)
    
    @staticmethod
    def _get_ping_impl(host: str) -> Optional[Dict[str, Any]]:
        """Реализация получения пинга"""
        try:
            import subprocess
            
            # Пинг для Windows
            if platform.system() == "Windows":
                command = ['ping', '-n', '1', '-w', '1000', host]
            else:
                command = ['ping', '-c', '1', '-W', '1', host]
            
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=2
            )
            
            if result.returncode == 0:
                # Парсим вывод ping
                output = result.stdout
                lines = output.split('\n')
                
                for line in lines:
                    if 'time=' in line or 'time<' in line:
                        try:
                            # Извлекаем время из строки
                            if 'time=' in line:
                                time_str = line.split('time=')[1].split(' ')[0]
                            else:
                                time_str = line.split('time<')[1].split(' ')[0]
                            
                            ping_ms = float(time_str)
                            
                            # Определение цвета
                            if ping_ms < 30:
                                color = "#00ff88"
                                status = "Отлично"
                            elif ping_ms < 60:
                                color = "#55aaff"
                                status = "Хорошо"
                            elif ping_ms < 100:
                                color = "#ffaa00"
                                status = "Средне"
                            else:
                                color = "#ff5555"
                                status = "Плохо"
                            
                            return {
                                'value': int(ping_ms),
                                'color': color,
                                'status': status,
                                'host': host
                            }
                            
                        except (ValueError, IndexError):
                            continue
            
            return {
                'value': 999,
                'color': "#ff5555",
                'status': "Таймаут",
                'host': host
            }
            
        except Exception as e:
            return {
                'value': 0,
                'color': "#888888",
                'status': "Ошибка",
                'host': host
            }
    
    @staticmethod
    def get_processes() -> List[Dict[str, Any]]:
        """Получение списка процессов"""
        key = "processes"
        return SystemMonitor.get_cached(key, SystemMonitor._get_processes_impl)
    
    @staticmethod
    def _get_processes_impl() -> List[Dict[str, Any]]:
        """Реализация получения списка процессов"""
        processes = []
        
        try:
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent', 'status']):
                try:
                    process_info = proc.info
                    # Фильтруем системные процессы с низкой загрузкой
                    if process_info['cpu_percent'] > 0.1 or process_info['memory_percent'] > 0.1:
                        processes.append({
                            'pid': process_info['pid'],
                            'name': process_info['name'][:30],
                            'cpu': f"{process_info['cpu_percent']:.1f}%",
                            'memory': f"{process_info['memory_percent']:.1f}%",
                            'status': process_info['status']
                        })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
                
                # Ограничиваем количество процессов
                if len(processes) >= 50:
                    break
            
            # Сортируем по использованию CPU
            processes.sort(key=lambda x: float(x['cpu'].rstrip('%')), reverse=True)
            
        except Exception as e:
            print(f"Ошибка получения процессов: {e}")
        
        return processes
    
    @staticmethod
    def format_bytes(bytes_num: int) -> str:
        """Форматирование байтов в читаемый вид"""
        if bytes_num == 0:
            return "0 B"
            
        units = ['B', 'KB', 'MB', 'GB', 'TB']
        unit_index = 0
        
        while bytes_num >= 1024 and unit_index < len(units) - 1:
            bytes_num /= 1024.0
            unit_index += 1
        
        return f"{bytes_num:.1f} {units[unit_index]}"
    
    # Методы для температур через встроенные средства
    @staticmethod
    def get_cpu_temperature():
        """Получение температуры CPU через доступные методы"""
        try:
            # Через psutil sensors
            if hasattr(psutil, "sensors_temperatures"):
                sensors = psutil.sensors_temperatures()
                if sensors:
                    cpu_temps = []
                    for name, entries in sensors.items():
                        if 'core' in name.lower() or 'cpu' in name.lower():
                            for entry in entries:
                                cpu_temps.append(entry.current)
                    
                    if cpu_temps:
                        return sum(cpu_temps) / len(cpu_temps)
            
            return 0
            
        except Exception:
            return 0
    
    @staticmethod
    def get_gpu_temperature(gpu_index=0):
        """Получение температуры GPU"""
        try:
            # Через GPUtil
            gpus = GPUtil.getGPUs()
            if gpu_index < len(gpus):
                return gpus[gpu_index].temperature
            
            return 0
            
        except Exception:
            return 0
    
    @staticmethod
    def get_detailed_cpu_info():
        """Получение детальной информации о CPU"""
        try:
            info = {}
            
            # Базовая информация
            info['Ядра (физ/лог)'] = f"{psutil.cpu_count(logical=False)}/{psutil.cpu_count(logical=True)}"
            
            freq = psutil.cpu_freq()
            if freq:
                info['Частота'] = f"{freq.current:.0f} МГц"
            
            # Температура
            cpu_temp = SystemMonitor.get_cpu_temperature()
            if cpu_temp > 0:
                info['Температура'] = f"{cpu_temp:.1f}°C"
            
            # Загрузка
            cpu_load = psutil.cpu_percent(interval=0.1)
            info['Загрузка'] = f"{cpu_load:.1f}%"
            
            return info
            
        except Exception:
            return {'Информация': 'Недоступна'}
    
    @staticmethod
    def get_detailed_gpu_info(gpu_index=0):
        """Получение детальной информации о GPU"""
        try:
            gpus = GPUtil.getGPUs()
            
            if gpu_index < len(gpus):
                gpu = gpus[gpu_index]
                info = {
                    'Модель': gpu.name[:30],
                    'Загрузка': f"{gpu.load * 100:.1f}%",
                    'Память': f"{gpu.memoryUsed}/{gpu.memoryTotal} MB",
                    'Исп. памяти': f"{(gpu.memoryUsed / gpu.memoryTotal) * 100:.1f}%"
                }
                
                if gpu.temperature:
                    info['Температура'] = f"{gpu.temperature:.1f}°C"
                    
                return info
            
            return {'Информация': 'GPU не обнаружены'}
            
        except Exception:
            return {'Информация': 'Недоступна'}
    
    @staticmethod
    def get_fan_speeds():
        """Получение скоростей вентиляторов"""
        # В реальной системе нужно использовать WMI или другие API
        # Здесь возвращаем примерные данные
        return [
            {'name': 'CPU Fan', 'speed': 1200, 'type': 'cpu'},
            {'name': 'Chassis Fan 1', 'speed': 800, 'type': 'case'},
            {'name': 'Chassis Fan 2', 'speed': 750, 'type': 'case'}
        ]

# Экспорт функций для обратной совместимости
def get_system_info():
    return SystemMonitor.get_system_info()

def get_battery_info():
    return SystemMonitor.get_battery_info()

def get_fps():
    return SystemMonitor.get_fps()

def get_ping(host="8.8.8.8"):
    return SystemMonitor.get_ping(host)

def get_gpu_info():
    return SystemMonitor.get_gpu_info()

def get_cpu_info():
    return SystemMonitor.get_cpu_info()

def get_processes():
    return SystemMonitor.get_processes()

def get_accurate_cpu_temperature():
    return SystemMonitor.get_cpu_temperature()

def get_accurate_gpu_temperature(gpu_index=0):
    return SystemMonitor.get_gpu_temperature(gpu_index)

def get_all_accurate_temperatures():
    # Упрощенная версия
    temps = {}
    cpu_temp = SystemMonitor.get_cpu_temperature()
    if cpu_temp:
        temps['cpu'] = cpu_temp
    
    gpu_temp = SystemMonitor.get_gpu_temperature(0)
    if gpu_temp:
        temps['gpu'] = gpu_temp
    
    return temps

def get_detailed_cpu_info():
    return SystemMonitor.get_detailed_cpu_info()

def get_detailed_gpu_info(gpu_index=0):
    return SystemMonitor.get_detailed_gpu_info(gpu_index)

def get_fan_speeds():
    return SystemMonitor.get_fan_speeds()

def get_temperatures():
    """Получение информации о температурах"""
    temps = {}
    
    try:
        if hasattr(psutil, "sensors_temperatures"):
            sensors = psutil.sensors_temperatures()
            if sensors:
                for name, entries in sensors.items():
                    for entry in entries:
                        label = entry.label or name
                        temps[label] = {
                            'current': entry.current,
                            'high': entry.high if hasattr(entry, 'high') else None,
                            'critical': entry.critical if hasattr(entry, 'critical') else None
                        }
    except Exception as e:
        pass
    
    return temps