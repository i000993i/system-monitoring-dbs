# overlay.py

import tkinter as tk
import time
import threading
import psutil
import subprocess
import platform
from utils import get_battery_info, get_cpu_info, get_gpu_info, get_accurate_cpu_temperature
from fps_monitor import get_current_fps

class PixelOverlay:
    def __init__(self, root, components):
        self.root = root
        self.components = components
        self.overlay_window = None
        self.labels = {}
        self.visible = False
        self.running = True
        self.is_dragging = False
        self.drag_start_x = 0
        self.drag_start_y = 0
        
        # Кэш данных для оптимизации
        self.data_cache = {}
        self.cache_time = {}
        self.cache_duration = {
            'cpu': 0.5,     # 500 мс
            'gpu': 0.5,     # 500 мс
            'ram': 0.3,     # 300 мс
            'fps': 0.1,     # 100 мс (чаще для FPS)
            'ping': 2.0,    # 2 секунды
            'battery': 5.0  # 5 секунд
        }
        
        # Данные для Ping
        self.ping_data = {
            'value': 0,
            'last_update': 0
        }
        
        self.create_overlay()
        self.start_update_thread()
    
    def create_overlay(self):
        """Создание оверлея в пиксельном стиле"""
        self.overlay_window = tk.Toplevel(self.root)
        self.overlay_window.title("SYSTEM HUD")
        self.overlay_window.geometry("280x110+20+20")
        self.overlay_window.overrideredirect(True)
        self.overlay_window.attributes("-topmost", True)
        self.overlay_window.configure(bg="#282a36")
        
        # Устанавливаем легкую полупрозрачность
        try:
            self.overlay_window.attributes("-alpha", 0.92)
        except Exception:
            pass
        
        # Рамка оверлея
        frame = tk.Frame(self.overlay_window, bg="#282a36", relief="raised", bd=1)
        frame.pack(fill="both", expand=True)
        
        # Заголовок с кнопкой закрытия (область для перемещения)
        header = tk.Frame(frame, bg="#44475a", height=25)
        header.pack(fill="x")
        header.pack_propagate(False)
        
        # Заголовок
        title_label = tk.Label(header, text="▌ SYSTEM HUD", bg="#44475a", fg="#f8f8f2",
                             font=("Courier New", 10, "bold"))
        title_label.pack(side="left", padx=8, pady=3)
        
        # Кнопка закрытия
        close_btn = tk.Label(header, text="✕", bg="#44475a", fg="#ff5555",
                           font=("Arial", 10, "bold"), cursor="hand2")
        close_btn.pack(side="right", padx=8, pady=3)
        close_btn.bind("<Button-1>", lambda e: self.toggle_visibility())
        
        # Контент
        content = tk.Frame(frame, bg="#282a36")
        content.pack(fill="both", expand=True, padx=8, pady=4)
        
        # Сетка для метрик (2 строки, 3 колонки)
        metrics_frame = tk.Frame(content, bg="#282a36")
        metrics_frame.pack(fill="both", expand=True)
        
        # Метрики
        metrics_config = [
            ("CPU", "#ff5555", 0, 0),
            ("GPU", "#ffb86c", 0, 1),
            ("RAM", "#50fa7b", 0, 2),
            ("FPS", "#00ff88", 1, 0),
            ("PING", "#55aaff", 1, 1),
            ("BAT", "#ff5555", 1, 2)
        ]
        
        for name, color, row, col in metrics_config:
            frame_cell = tk.Frame(metrics_frame, bg="#282a36")
            frame_cell.grid(row=row, column=col, padx=2, pady=2, sticky="nsew")
            
            # Название метрики
            tk.Label(frame_cell, text=name, bg="#282a36", fg="#f8f8f2",
                    font=("Courier New", 8)).pack()
            
            # Значение метрики
            value_label = tk.Label(frame_cell, text="---", bg="#282a36", fg=color,
                                  font=("Courier New", 10, "bold"))
            value_label.pack()
            
            self.labels[name] = value_label
            
            # Настройка grid
            metrics_frame.columnconfigure(col, weight=1)
            metrics_frame.rowconfigure(row, weight=1)
        
        # Перемещение оверлея - привязываем ко всей header области
        header.bind("<ButtonPress-1>", self.start_drag)
        header.bind("<ButtonRelease-1>", self.stop_drag)
        header.bind("<B1-Motion>", self.do_drag)
        
        # Двойной клик для скрытия/показа
        header.bind("<Double-Button-1>", lambda e: self.toggle_visibility())
        
        # Скрываем по умолчанию
        self.overlay_window.withdraw()
    
    def start_drag(self, event):
        """Начало перемещения окна"""
        self.is_dragging = True
        self.drag_start_x = event.x_root
        self.drag_start_y = event.y_root
        
        # Получаем текущее положение окна
        self.overlay_window_x = self.overlay_window.winfo_x()
        self.overlay_window_y = self.overlay_window.winfo_y()
    
    def stop_drag(self, event):
        """Остановка перемещения"""
        self.is_dragging = False
    
    def do_drag(self, event):
        """Перемещение окна"""
        if self.is_dragging:
            # Вычисляем смещение
            delta_x = event.x_root - self.drag_start_x
            delta_y = event.y_root - self.drag_start_y
            
            # Вычисляем новую позицию
            new_x = self.overlay_window_x + delta_x
            new_y = self.overlay_window_y + delta_y
            
            # Устанавливаем новую позицию
            self.overlay_window.geometry(f"+{int(new_x)}+{int(new_y)}")
    
    def get_cached_data(self, key, getter_func):
        """Получение данных с кэшированием"""
        current_time = time.time()
        cache_duration = self.cache_duration.get(key, 1.0)
        
        if key in self.data_cache:
            last_time = self.cache_time.get(key, 0)
            if current_time - last_time < cache_duration:
                return self.data_cache[key]
        
        try:
            data = getter_func()
            self.data_cache[key] = data
            self.cache_time[key] = current_time
            return data
        except Exception as e:
            if key in self.data_cache:
                return self.data_cache[key]
            return None
    
    def get_ping_data(self):
        """Получение реальных данных Ping"""
        current_time = time.time()
        
        # Обновляем ping раз в 2 секунды
        if current_time - self.ping_data['last_update'] >= 2.0:
            try:
                # Тестируем ping до популярных серверов
                test_hosts = ["8.8.8.8"]
                
                best_ping = 999
                successful_pings = 0
                
                for host in test_hosts:
                    try:
                        # Команда ping для разных ОС
                        if platform.system().lower() == 'windows':
                            command = ['ping', '-n', '1', '-w', '1000', host]
                        else:
                            command = ['ping', '-c', '1', '-W', '1', host]
                        
                        result = subprocess.run(
                            command,
                            capture_output=True,
                            text=True,
                            timeout=2,
                            creationflags=subprocess.CREATE_NO_WINDOW if platform.system().lower() == 'windows' else 0
                        )
                        
                        if result.returncode == 0:
                            # Парсим результат
                            output = result.stdout
                            for line in output.split('\n'):
                                if 'time=' in line or 'time<' in line:
                                    try:
                                        # Извлекаем время из строки
                                        if 'time=' in line:
                                            time_str = line.split('time=')[1].split(' ')[0]
                                        else:
                                            time_str = line.split('time<')[1].split(' ')[0]
                                        
                                        # Убираем нечисловые символы
                                        time_str = ''.join(c for c in time_str if c.isdigit() or c == '.')
                                        ping_ms = float(time_str)
                                        
                                        if ping_ms < best_ping:
                                            best_ping = ping_ms
                                        successful_pings += 1
                                        break
                                    except (ValueError, IndexError):
                                        continue
                    except (subprocess.TimeoutExpired, FileNotFoundError):
                        continue
                
                if successful_pings > 0 and best_ping < 999:
                    self.ping_data['value'] = int(best_ping)
                else:
                    if self.ping_data['value'] == 0:
                        self.ping_data['value'] = 999
                
                self.ping_data['last_update'] = current_time
                
            except Exception:
                if self.ping_data['value'] == 0:
                    self.ping_data['value'] = 999
        
        return self.ping_data['value']
    
    def start_update_thread(self):
        """Запуск оптимизированного потока обновления данных"""
        def update_loop():
            while self.running and hasattr(self, 'overlay_window'):
                try:
                    if self.visible:
                        self.root.after(0, self.update_data)
                    time.sleep(1.0)  # Обновляем раз в секунду
                except Exception:
                    time.sleep(1)
        
        self.update_thread = threading.Thread(target=update_loop, daemon=True)
        self.update_thread.start()
    
    def update_data(self):
        """Обновление всех данных"""
        if not self.visible or not self.overlay_window:
            return
        
        try:
            # CPU
            cpu_info = self.get_cached_data('cpu', get_cpu_info)
            if cpu_info and 'Usage' in cpu_info:
                cpu_load = cpu_info['Usage']['Total'].replace('%', '')
                try:
                    cpu_value = float(cpu_load)
                    
                    # Получаем температуру CPU
                    cpu_temp = get_accurate_cpu_temperature()
                    
                    # Формируем текст
                    if cpu_temp > 0:
                        cpu_text = f"{cpu_value:.0f}%\n{cpu_temp:.0f}°C"
                        
                        # Цвет в зависимости от температуры
                        if cpu_temp > 80:
                            cpu_color = "#ff5555"
                        elif cpu_temp > 70:
                            cpu_color = "#ffaa00"
                        else:
                            cpu_color = "#ff5555"
                    else:
                        cpu_text = f"{cpu_value:.0f}%"
                        cpu_color = "#ff5555"
                    
                    self.labels["CPU"].config(text=cpu_text, fg=cpu_color)
                except ValueError:
                    self.labels["CPU"].config(text="N/A", fg="#888888")
            else:
                self.labels["CPU"].config(text="N/A", fg="#888888")
            
            # GPU
            gpu_info = self.get_cached_data('gpu', get_gpu_info)
            if gpu_info and len(gpu_info) > 0:
                gpu_load = gpu_info[0]['Load'].replace('%', '')
                gpu_temp_str = gpu_info[0].get('Temperature', '0°C').replace('°C', '')
                
                try:
                    gpu_value = float(gpu_load)
                    gpu_temp = float(gpu_temp_str) if gpu_temp_str.replace('.', '').isdigit() else 0
                    
                    # Формируем текст
                    if gpu_temp > 0:
                        gpu_text = f"{gpu_value:.0f}%\n{gpu_temp:.0f}°C"
                        
                        # Цвет в зависимости от температуры
                        if gpu_temp > 85:
                            gpu_color = "#ff5555"
                        elif gpu_temp > 75:
                            gpu_color = "#ffaa00"
                        else:
                            gpu_color = "#ffb86c"
                    else:
                        gpu_text = f"{gpu_value:.0f}%"
                        gpu_color = "#ffb86c"
                    
                    self.labels["GPU"].config(text=gpu_text, fg=gpu_color)
                except ValueError:
                    self.labels["GPU"].config(text="N/A", fg="#888888")
            else:
                self.labels["GPU"].config(text="N/A", fg="#888888")
            
            # RAM
            try:
                ram = psutil.virtual_memory()
                self.labels["RAM"].config(text=f"{ram.percent:.0f}%", fg="#50fa7b")
            except Exception:
                self.labels["RAM"].config(text="N/A", fg="#888888")
            
            # FPS
            try:
                fps_value = get_current_fps()
                if fps_value > 0:
                    if fps_value >= 60:
                        fps_color = "#00ff88"
                    elif fps_value >= 30:
                        fps_color = "#ffaa00"
                    else:
                        fps_color = "#ff5555"
                    
                    self.labels["FPS"].config(text=f"{fps_value}", fg=fps_color)
                else:
                    self.labels["FPS"].config(text="N/A", fg="#888888")
            except Exception:
                self.labels["FPS"].config(text="N/A", fg="#888888")
            
            # PING
            try:
                ping_value = self.get_ping_data()
                if ping_value < 999:
                    if ping_value < 30:
                        ping_color = "#00ff88"
                    elif ping_value < 60:
                        ping_color = "#55aaff"
                    elif ping_value < 100:
                        ping_color = "#ffaa00"
                    else:
                        ping_color = "#ff5555"
                    
                    self.labels["PING"].config(text=f"{ping_value}ms", fg=ping_color)
                else:
                    self.labels["PING"].config(text="∞", fg="#ff5555")
            except Exception:
                self.labels["PING"].config(text="N/A", fg="#888888")
            
            # Battery
            battery = self.get_cached_data('battery', get_battery_info)
            if battery:
                battery_color = battery['color']
                battery_text = f"{battery['percent']}%"
                self.labels["BAT"].config(text=battery_text, fg=battery_color)
            else:
                self.labels["BAT"].config(text="N/A", fg="#888888")
            
        except Exception:
            pass
    
    def toggle_visibility(self):
        """Переключение видимости оверлея"""
        if self.visible:
            self.hide()
        else:
            self.show()
    
    def show(self):
        """Показать оверлей"""
        if self.overlay_window:
            try:
                self.overlay_window.deiconify()
                self.overlay_window.lift()
                self.overlay_window.attributes("-topmost", True)
                self.visible = True
                self.update_data()
            except Exception:
                pass
    
    def hide(self):
        """Скрыть оверлей"""
        if self.overlay_window:
            try:
                self.overlay_window.withdraw()
                self.visible = False
            except Exception:
                pass
    
    def is_visible(self):
        """Проверка видимости оверлея"""
        return self.visible
    
    def destroy(self):
        """Уничтожение оверлея"""
        self.running = False
        if self.overlay_window:
            try:
                self.overlay_window.destroy()
            except Exception:
                pass