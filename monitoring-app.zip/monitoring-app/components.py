# components.py

import tkinter as tk
from tkinter import ttk
import time
from utils import (
    get_system_info, get_battery_info, get_cpu_info, get_gpu_info, get_processes,
    get_detailed_cpu_info, get_detailed_gpu_info, get_fan_speeds, get_accurate_cpu_temperature,
    get_temperatures
)
import psutil

class Components:
    def __init__(self, app=None):
        self.app = app
        self.cards = {}
        self.processes_frame = None
        self.current_column_count = 3
        self.canvas = None
        self.scrollbar = None
        self.scrollable_frame = None
        self.monitor_grid = None
        self.last_update_time = 0
        self.update_interval = 2  # секунды
        
    def create_monitor_tab(self, notebook):
        """Создание вкладки 'Монитор' с исправленным адаптивным дизайном"""
        monitor_frame = tk.Frame(notebook, bg="#282a36")
        notebook.add(monitor_frame, text="📟 МОНИТОР")
        
        # Упрощенный контейнер без горизонтальной прокрутки
        container = tk.Frame(monitor_frame, bg="#282a36")
        container.pack(fill="both", expand=True)
        
        # Вертикальная прокрутка
        v_scrollbar = tk.Scrollbar(container, orient="vertical")
        v_scrollbar.pack(side="right", fill="y")
        
        # Canvas с вертикальной прокруткой
        self.canvas = tk.Canvas(
            container, 
            bg="#282a36", 
            highlightthickness=0,
            yscrollcommand=v_scrollbar.set
        )
        self.canvas.pack(side="left", fill="both", expand=True)
        
        v_scrollbar.config(command=self.canvas.yview)
        
        # Фрейм внутри Canvas
        self.scrollable_frame = tk.Frame(self.canvas, bg="#282a36")
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        
        # Сетка для карточек
        self.monitor_grid = tk.Frame(self.scrollable_frame, bg="#282a36")
        self.monitor_grid.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Привязка изменения размера
        self.scrollable_frame.bind("<Configure>", self.on_frame_configure)
        self.canvas.bind("<Configure>", self.on_canvas_configure)
        
        # Привязка колесика мыши
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)
        
        # Создаем карточки (только основные, без детальных)
        self.create_all_cards()
        
        # Начальное обновление
        self.update_card_data_from_main_thread()
        
        return monitor_frame
    
    def on_frame_configure(self, event=None):
        """Обновление прокрутки при изменении размера фрейма"""
        if self.canvas:
            self.canvas.configure(scrollregion=self.canvas.bbox("all"))
            self.adjust_columns()
    
    def on_canvas_configure(self, event=None):
        """Обработчик изменения размера Canvas"""
        if self.canvas and self.scrollable_frame:
            # Устанавливаем ширину scrollable_frame равной ширине canvas
            self.canvas.itemconfig(1, width=self.canvas.winfo_width())
            self.adjust_columns()
    
    def _on_mousewheel(self, event):
        """Прокрутка по вертикали"""
        if self.canvas:
            self.canvas.yview_scroll(int(-1*(event.delta/120)), "units")
    
    def adjust_columns(self):
        """Автоматическая настройка количества колонок"""
        if not self.monitor_grid:
            return
            
        # Получаем доступную ширину
        if self.canvas:
            available_width = self.canvas.winfo_width() - 40  # Отступы
        else:
            available_width = self.monitor_grid.winfo_width()
        
        # Определяем оптимальное количество колонок
        if available_width < 400:
            columns = 1
        elif available_width < 700:
            columns = 2
        elif available_width < 1000:
            columns = 3
        else:
            columns = 4
        
        # Если количество колонок изменилось, перестраиваем сетку
        if columns != self.current_column_count:
            self.current_column_count = columns
            self.rebuild_cards_grid()
    
    def create_all_cards(self):
        """Создание всех карточек (только основные)"""
        card_configs = [
            ("system", "⚙️ СИСТЕМА", "#ff5555"),
            ("cpu", "⚡ ЦП", "#ffb86c"),
            ("ram", "🧠 ОЗУ", "#50fa7b"),
            ("disk", "💾 ДИСКИ", "#bd93f9"),
            ("gpu", "🎮 ВИДЕОКАРТЫ", "#ff5555"),
            ("network", "🌐 СЕТЬ", "#55aaff"),
            ("battery", "🔋 БАТАРЕЯ", "#00ff88"),
            ("temp", "🌡️ ТЕМПЕРАТУРЫ", "#ff79c6"),
        ]
        
        for key, title, color in card_configs:
            self.cards[key] = {
                'title': title,
                'color': color,
                'frame': None,
                'text': None,
                'title_label': None,
                'content_frame': None
            }
    
    def rebuild_cards_grid(self):
        """Перестроение сетки карточек"""
        if not self.monitor_grid or not self.cards:
            return
            
        # Удаляем все старые виджеты из сетки
        for widget in self.monitor_grid.winfo_children():
            widget.destroy()
        
        # Создаем новую сетку
        card_items = list(self.cards.items())
        columns = min(self.current_column_count, len(card_items))
        
        # Настраиваем сетку
        for i in range(columns):
            self.monitor_grid.columnconfigure(i, weight=1, minsize=300)
        
        for i, (key, card_info) in enumerate(card_items):
            row = i // columns
            col = i % columns
            
            # Создаем фрейм карточки
            card_frame = tk.Frame(
                self.monitor_grid, 
                bg=card_info['color'], 
                relief="sunken", 
                bd=1,
                width=300,
                height=150
            )
            card_frame.grid(row=row, column=col, sticky="nsew", padx=5, pady=5)
            card_frame.grid_propagate(False)  # Фиксируем размер
            
            # Заголовок карточки
            title_frame = tk.Frame(card_frame, bg="#282a36", height=30)
            title_frame.pack(fill="x", padx=1, pady=1)
            title_frame.pack_propagate(False)
            
            title_label = tk.Label(
                title_frame, 
                text=f"▌ {card_info['title']}", 
                bg="#282a36", 
                fg="#f8f8f2",
                font=("Courier New", 11, "bold"), 
                anchor="w"
            )
            title_label.pack(side="left", padx=5, pady=2, fill="x", expand=True)
            
            # Контент
            content_frame = tk.Frame(card_frame, bg="#44475a")
            content_frame.pack(fill="both", expand=True, padx=1, pady=1)
            
            # Текстовое поле для информации
            info_text = tk.Text(
                content_frame,
                bg="#44475a",
                fg="#f8f8f2",
                font=("Courier New", 10),
                wrap="word",
                relief="flat",
                borderwidth=0,
                highlightthickness=0,
                spacing1=2,
                spacing2=1,
                spacing3=2,
                state="disabled"
            )
            info_text.pack(fill="both", expand=True, padx=8, pady=8)
            
            # Сохраняем ссылки
            self.cards[key]['frame'] = card_frame
            self.cards[key]['text'] = info_text
            self.cards[key]['title_label'] = title_label
            self.cards[key]['content_frame'] = content_frame
        
        # Обновляем прокрутку после перестроения
        if self.canvas:
            self.canvas.configure(scrollregion=self.canvas.bbox("all"))
    
    def update_card_data_from_main_thread(self):
        """Обновление данных в карточках (вызывается из главного потока)"""
        current_time = time.time()
        
        # Проверяем интервал обновления (чтобы избежать мерцания)
        if current_time - self.last_update_time < self.update_interval:
            return
            
        self.last_update_time = current_time
        
        # Если карточки еще не созданы в сетке, создаем их
        if not hasattr(self, 'monitor_grid') or not self.monitor_grid.winfo_children():
            self.rebuild_cards_grid()
            return
        
        try:
            # Системная информация
            sys_info = get_system_info()
            if sys_info:
                sys_text = f"ОС: {sys_info.get('OS', 'N/A')}\n"
                sys_text += f"Версия: {sys_info.get('Release', 'N/A')}\n"
                sys_text += f"Архитектура: {sys_info.get('Architecture', 'N/A')}\n"
                sys_text += f"Имя ПК: {sys_info.get('Hostname', 'N/A')[:15]}"
                self.update_card_text('system', sys_text)
            
            # CPU информация
            cpu_info = get_cpu_info()
            if cpu_info:
                cpu_text = f"Загрузка: {cpu_info.get('Usage', {}).get('Total', 'N/A')}\n"
                if 'Frequency' in cpu_info:
                    freq = cpu_info['Frequency'].get('Current', 'N/A')
                    if 'МГц' in str(freq):
                        cpu_text += f"Частота: {freq}\n"
                if 'Cores' in cpu_info:
                    cpu_text += f"Ядра: {cpu_info['Cores'].get('Physical', 'N/A')}/{cpu_info['Cores'].get('Logical', 'N/A')}"
                
                # Добавляем температуру CPU если доступна
                cpu_temp = get_accurate_cpu_temperature()
                if cpu_temp > 0:
                    cpu_text += f"\nТемпература: {cpu_temp:.1f}°C"
                
                self.update_card_text('cpu', cpu_text)
            
            # RAM информация
            try:
                ram = psutil.virtual_memory()
                ram_total_gb = ram.total // (1024**3)
                ram_used_gb = ram.used // (1024**3)
                ram_avail_gb = ram.available // (1024**3)
                
                ram_text = f"Всего: {ram_total_gb} GB\n"
                ram_text += f"Использовано: {ram_used_gb} GB\n"
                ram_text += f"Доступно: {ram_avail_gb} GB\n"
                ram_text += f"Загрузка: {ram.percent}%"
                self.update_card_text('ram', ram_text)
            except Exception:
                self.update_card_text('ram', "Ошибка RAM")
            
            # Диски (максимум 2 диска)
            disks_text = ""
            try:
                disk_count = 0
                for partition in psutil.disk_partitions():
                    try:
                        if disk_count >= 2:
                            break
                        usage = psutil.disk_usage(partition.mountpoint)
                        if usage.total > 0:
                            disk_name = partition.mountpoint.replace(':\\', '')
                            disks_text += f"{disk_name}: {usage.percent:.1f}%\n"
                            disks_text += f"  Свободно: {usage.free // (1024**3)} GB\n"
                            disk_count += 1
                    except Exception:
                        continue
                if not disks_text:
                    disks_text = "Диски не найдены"
                self.update_card_text('disk', disks_text)
            except Exception:
                self.update_card_text('disk', "Ошибка дисков")
            
            # GPU информация
            gpu_text = ""
            try:
                gpu_info = get_gpu_info()
                if gpu_info and len(gpu_info) > 0:
                    gpu = gpu_info[0]
                    name = gpu.get('Name', 'GPU')
                    if len(name) > 20:
                        name = name[:17] + "..."
                    gpu_text += f"{name}:\n"
                    gpu_text += f"Загрузка: {gpu.get('Load', 'N/A')}\n"
                    gpu_text += f"Память: {gpu.get('Memory Percent', 'N/A')}\n"
                    gpu_text += f"Темп: {gpu.get('Temperature', 'N/A')}"
                else:
                    gpu_text = "GPU не обнаружены"
                self.update_card_text('gpu', gpu_text)
            except Exception:
                self.update_card_text('gpu', "Ошибка GPU")
            
            # Сеть
            try:
                net_io = psutil.net_io_counters()
                sent_gb = net_io.bytes_sent // (1024**3)
                recv_gb = net_io.bytes_recv // (1024**3)
                
                net_text = f"Отправлено: {sent_gb} GB\n"
                net_text += f"Получено: {recv_gb} GB\n"
                net_text += f"Пакеты:\n"
                net_text += f"  Отпр: {net_io.packets_sent // 1000}K\n"
                net_text += f"  Прием: {net_io.packets_recv // 1000}K"
                self.update_card_text('network', net_text)
            except Exception:
                self.update_card_text('network', "Ошибка сети")
            
            # Батарея
            try:
                battery = get_battery_info()
                if battery:
                    bat_text = f"Заряд: {battery.get('percent', 'N/A')}%\n"
                    bat_text += f"Статус: {battery.get('status', 'N/A')}\n"
                    time_left = battery.get('time_left', 'N/A')
                    if time_left and time_left != 'N/A':
                        bat_text += f"Осталось: {time_left}"
                    self.update_card_text('battery', bat_text)
                else:
                    self.update_card_text('battery', "Питание от сети")
            except Exception:
                self.update_card_text('battery', "Ошибка батареи")
            
            # Температуры
            try:
                temps = get_temperatures()
                if temps:
                    temp_text = ""
                    count = 0
                    for sensor_name, temp_data in temps.items():
                        if count >= 3:  # Ограничиваем 3 датчика
                            break
                        current_temp = temp_data.get('current', 0)
                        if current_temp > 0:
                            # Сокращаем длинные названия
                            name = sensor_name[:12] + "..." if len(sensor_name) > 15 else sensor_name
                            temp_text += f"{name}: {current_temp:.1f}°C\n"
                            count += 1
                    
                    if temp_text:
                        self.update_card_text('temp', temp_text)
                    else:
                        # Если нет датчиков, показываем CPU температуру
                        cpu_temp = get_accurate_cpu_temperature()
                        if cpu_temp > 0:
                            self.update_card_text('temp', f"CPU: {cpu_temp:.1f}°C")
                        else:
                            self.update_card_text('temp', "Датчики не найдены")
                else:
                    # Если нет датчиков, показываем CPU температуру
                    cpu_temp = get_accurate_cpu_temperature()
                    if cpu_temp > 0:
                        self.update_card_text('temp', f"CPU: {cpu_temp:.1f}°C")
                    else:
                        self.update_card_text('temp', "Датчики не найдены")
            except Exception:
                self.update_card_text('temp', "Ошибка температур")
            
        except Exception as e:
            print(f"Ошибка обновления карточек: {e}")
    
    def update_card_text(self, card_key, text):
        """Обновление текста в карточке (без мерцания)"""
        if card_key in self.cards:
            try:
                card = self.cards[card_key]
                text_widget = card.get('text')
                if text_widget:
                    # Проверяем, изменился ли текст
                    current_text = text_widget.get("1.0", tk.END).strip()
                    if current_text != text.strip():
                        text_widget.config(state="normal")
                        text_widget.delete("1.0", tk.END)
                        text_widget.insert("1.0", text)
                        text_widget.config(state="disabled")
            except Exception as e:
                print(f"Ошибка обновления карточки {card_key}: {e}")
    
    def force_refresh(self):
        """Принудительное обновление всех данных"""
        self.last_update_time = 0  # Сбрасываем время последнего обновления
        self.update_card_data_from_main_thread()
    
    def create_processes_tab(self, notebook):
        """Создание вкладки 'Процессы'"""
        processes_frame = tk.Frame(notebook, bg="#282a36")
        notebook.add(processes_frame, text="🔍 ПРОЦЕССЫ")
        
        # Упрощенный контейнер
        container = tk.Frame(processes_frame, bg="#282a36")
        container.pack(fill="both", expand=True)
        
        # Canvas и скроллбар
        canvas = tk.Canvas(container, bg="#282a36", highlightthickness=0)
        v_scrollbar = tk.Scrollbar(container, orient="vertical", command=canvas.yview)
        
        scrollable_frame = tk.Frame(canvas, bg="#282a36")
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=v_scrollbar.set)
        
        # Упаковка
        canvas.pack(side="left", fill="both", expand=True)
        v_scrollbar.pack(side="right", fill="y")
        
        # Заголовки таблицы
        headers_frame = tk.Frame(scrollable_frame, bg="#44475a")
        headers_frame.pack(fill="x", padx=10, pady=(10, 0))
        
        headers = ["PID", "Имя процесса", "CPU %", "RAM %", "Статус"]
        
        for i, header in enumerate(headers):
            tk.Label(
                headers_frame,
                text=header,
                bg="#44475a",
                fg="#f8f8f2",
                font=("Courier New", 10, "bold"),
                width=15 if i == 1 else 10,
                anchor="w"
            ).grid(row=0, column=i, padx=2, pady=2, sticky="w")
        
        # Область для процессов
        self.processes_frame = tk.Frame(scrollable_frame, bg="#282a36")
        self.processes_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        
        # Начальное обновление
        self.update_processes_list()
        
        return processes_frame
    
    def update_processes_list(self):
        """Обновление списка процессов"""
        try:
            # Очищаем старые процессы
            for widget in self.processes_frame.winfo_children():
                widget.destroy()
            
            # Получаем новые процессы
            processes = get_processes()
            
            # Отображаем процессы (максимум 30)
            for i, proc in enumerate(processes[:30]):
                bg_color = "#282a36" if i % 2 == 0 else "#44475a"
                row_frame = tk.Frame(self.processes_frame, bg=bg_color)
                row_frame.pack(fill="x", padx=2, pady=1)
                
                # PID
                tk.Label(
                    row_frame,
                    text=str(proc['pid']),
                    bg=bg_color,
                    fg="#f8f8f2",
                    font=("Courier New", 9),
                    width=10,
                    anchor="w"
                ).pack(side="left", padx=2)
                
                # Имя процесса
                name = proc['name']
                if len(name) > 20:
                    name = name[:17] + "..."
                tk.Label(
                    row_frame,
                    text=name,
                    bg=bg_color,
                    fg="#f8f8f2",
                    font=("Courier New", 9),
                    width=20,
                    anchor="w"
                ).pack(side="left", padx=2)
                
                # CPU
                cpu_val = float(proc['cpu'].rstrip('%'))
                cpu_color = "#ff5555" if cpu_val > 50 else "#ffaa00" if cpu_val > 20 else "#50fa7b"
                tk.Label(
                    row_frame,
                    text=proc['cpu'],
                    bg=bg_color,
                    fg=cpu_color,
                    font=("Courier New", 9),
                    width=10,
                    anchor="w"
                ).pack(side="left", padx=2)
                
                # RAM
                ram_val = float(proc['memory'].rstrip('%'))
                ram_color = "#ff5555" if ram_val > 30 else "#ffaa00" if ram_val > 10 else "#50fa7b"
                tk.Label(
                    row_frame,
                    text=proc['memory'],
                    bg=bg_color,
                    fg=ram_color,
                    font=("Courier New", 9),
                    width=10,
                    anchor="w"
                ).pack(side="left", padx=2)
                
                # Статус
                status = proc['status']
                status_color = "#50fa7b" if status == 'running' else "#ffaa00"
                tk.Label(
                    row_frame,
                    text=status[:8],
                    bg=bg_color,
                    fg=status_color,
                    font=("Courier New", 9),
                    width=10,
                    anchor="w"
                ).pack(side="left", padx=2)
                
        except Exception as e:
            print(f"Ошибка обновления процессов: {e}")
    
    def create_logs_tab(self, notebook):
        """Создание вкладки 'Лог'"""
        logs_frame = tk.Frame(notebook, bg="#282a36")
        notebook.add(logs_frame, text="📋 ЛОГИ")
        
        # Текстовое поле для логов с прокруткой
        text_frame = tk.Frame(logs_frame, bg="#282a36")
        text_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        text_scrollbar = tk.Scrollbar(text_frame)
        text_scrollbar.pack(side="right", fill="y")
        
        log_text = tk.Text(
            text_frame,
            bg="#282a36",
            fg="#f8f8f2",
            font=("Courier New", 10),
            wrap="word",
            relief="sunken",
            bd=1,
            yscrollcommand=text_scrollbar.set
        )
        log_text.pack(side="left", fill="both", expand=True)
        text_scrollbar.config(command=log_text.yview)
        
        # Настройка тегов для логов
        log_text.tag_config("info", foreground="#55aaff")
        log_text.tag_config("success", foreground="#00ff88")
        log_text.tag_config("warning", foreground="#ffaa00")
        log_text.tag_config("error", foreground="#ff5555")
        
        # Добавляем тестовые логи
        import datetime
        current_time = datetime.datetime.now().strftime("%H:%M:%S")
        log_text.insert("1.0", f"=== Лог системы [{current_time}] ===\n\n", "info")
        log_text.insert(tk.END, "✅ Системный монитор запущен\n", "success")
        log_text.insert(tk.END, "✅ Мониторинг CPU/GPU/RAM активен\n", "success")
        log_text.insert(tk.END, "✅ Графики загрузки активны\n", "success")
        log_text.insert(tk.END, "✅ Мониторинг процессов активен\n", "success")
        log_text.insert(tk.END, "⚠️  Для FPS монитора требуется запуск игр\n", "warning")
        log_text.insert(tk.END, "ℹ️  Температуры доступны через системные датчики\n", "info")
        
        log_text.config(state="disabled")
        
        return logs_frame