# main.py
# Автономный системный монитор

import tkinter as tk
from tkinter import ttk
import time
import psutil
from styles import apply_styles
from components import Components
from overlay import PixelOverlay
from graph import GraphManager
from fps_monitor import get_fps_monitor

class SystemMonitor:
    def __init__(self):
        # Создание главного окна
        self.root = tk.Tk()
        self.root.title("System Monitor v1.0")
        self.root.geometry("1200x800")
        
        # Защита от повторного запуска
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        
        # Применение стилей Dracula
        apply_styles(self.root)
        
        # Переменные для управления
        self.running = True
        self.is_fullscreen = False
        
        # Инициализация компонентов
        self.components = Components(self)
        self.graph_manager = None
        self.overlay = None
        
        # Создание интерфейса
        self.create_interface()
        
        # Центрирование окна
        self.center_window()
        
        # Настройка иконки (если есть)
        self.setup_icon()
        
        # Запуск обновлений
        self.start_updates()
        
        # Привязка горячих клавиш
        self.setup_hotkeys()
        
        # Статус инициализации
        self.status_messages = []
        self.add_status_message("✅ Приложение инициализировано")
        self.add_status_message("✅ Интерфейс создан")
        self.add_status_message("✅ Мониторинг запущен")
    
    def center_window(self):
        """Центрирование окна на экране"""
        self.root.update_idletasks()
        width = 1200
        height = 800
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
    
    def setup_icon(self):
        """Настройка иконки приложения"""
        try:
            # Можно добавить иконку .ico файл
            # self.root.iconbitmap('icon.ico')
            pass
        except Exception:
            pass
    
    def create_interface(self):
        """Создание основного интерфейса"""
        # Устанавливаем минимальный размер окна
        self.root.minsize(800, 600)
        
        # Основная область
        main_frame = tk.Frame(self.root, bg="#282a36")
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Панель вкладок
        self.create_notebook(main_frame)
        
        # Нижняя статус-панель
        self.create_status_bar()
        
        # Меню (опционально)
        self.create_menu()
    
    def create_notebook(self, parent):
        """Создание панели вкладок"""
        # Стиль для вкладок
        style = ttk.Style()
        style.configure("Custom.TNotebook", background="#282a36", borderwidth=0)
        style.configure("Custom.TNotebook.Tab", 
                       background="#44475a",
                       foreground="#f8f8f2",
                       padding=[15, 5],
                       font=("Courier New", 11))
        style.map("Custom.TNotebook.Tab",
                 background=[("selected", "#6272a4"), ("active", "#6272a4")],
                 foreground=[("selected", "#ff79c6"), ("active", "#ff79c6")])
        
        # Notebook с кастомным стилем
        self.notebook = ttk.Notebook(parent, style="Custom.TNotebook")
        self.notebook.pack(fill="both", expand=True)
        
        # Создаем вкладки
        self.create_tabs()
    
    def create_tabs(self):
        """Создание всех вкладок приложения"""
        # Монитор (основная вкладка)
        self.monitor_frame = self.components.create_monitor_tab(self.notebook)
        
        # Графики (создаем с задержкой для оптимизации)
        self.create_graphs_tab()
        
        # Процессы
        self.processes_frame = self.components.create_processes_tab(self.notebook)
        
        # Логи
        self.logs_frame = self.components.create_logs_tab(self.notebook)
    
    def create_graphs_tab(self):
        """Создание вкладки графиков с оптимизацией"""
        # Временная вкладка для отображения во время загрузки
        temp_frame = tk.Frame(self.notebook, bg="#282a36")
        self.notebook.add(temp_frame, text="📈 ГРАФИКИ")
        
        loading_label = tk.Label(
            temp_frame, 
            text="Загрузка графиков...", 
            bg="#282a36", 
            fg="#f8f8f2", 
            font=("Courier New", 14)
        )
        loading_label.pack(expand=True)
        
        # Создаем реальные графики через 500 мс (после отрисовки интерфейса)
        self.root.after(500, self._create_real_graphs_tab, temp_frame)
    
    def _create_real_graphs_tab(self, temp_frame):
        """Создание реальной вкладки графиков"""
        try:
            # Удаляем временную вкладку
            for i in range(self.notebook.index("end")):
                if self.notebook.tab(i, "text") == "📈 ГРАФИКИ":
                    self.notebook.forget(i)
                    break
            
            # Создаем менеджер графиков
            self.graph_manager = GraphManager(self)
            
            # Создаем реальную вкладку
            real_frame = self.graph_manager.create_graph_tab(self.notebook)
            
            # Вставляем на ту же позицию
            self.notebook.insert(1, real_frame, text="📈 ГРАФИКИ")
            
            self.add_status_message("✅ Графики инициализированы")
            
        except Exception as e:
            print(f"Ошибка создания графиков: {e}")
            # В случае ошибки оставляем сообщение
            error_frame = tk.Frame(self.notebook, bg="#282a36")
            self.notebook.add(error_frame, text="📈 ГРАФИКИ")
            
            error_label = tk.Label(
                error_frame, 
                text="Ошибка загрузки графиков", 
                bg="#282a36", 
                fg="#ff5555", 
                font=("Courier New", 12)
            )
            error_label.pack(expand=True)
            
            retry_btn = tk.Button(
                error_frame,
                text="Повторить",
                command=lambda: self.retry_graphs_tab(error_frame),
                bg="#44475a",
                fg="#f8f8f2",
                font=("Courier New", 10),
                relief="raised",
                bd=1
            )
            retry_btn.pack(pady=10)
    
    def retry_graphs_tab(self, error_frame):
        """Повторная попытка создания вкладки графиков"""
        try:
            self.notebook.forget(error_frame)
            self.create_graphs_tab()
        except Exception:
            pass
    
    def create_status_bar(self):
        """Создание нижней статус-панели"""
        status_frame = tk.Frame(self.root, bg="#282a36", relief="sunken", bd=1, height=28)
        status_frame.pack(fill="x", side="bottom", padx=10, pady=(0, 10))
        status_frame.pack_propagate(False)
        
        # Левая часть: информация о системе
        left_frame = tk.Frame(status_frame, bg="#282a36")
        left_frame.pack(side="left", fill="x", expand=True)
        
        # Время обновления
        self.update_time_label = tk.Label(
            left_frame, 
            text="Обновлено: --:--:--", 
            bg="#282a36", 
            fg="#888888",
            font=("Courier New", 9),
            anchor="w"
        )
        self.update_time_label.pack(side="left", padx=10)
        
        # Время работы системы
        self.uptime_label = tk.Label(
            left_frame, 
            text="Время работы: --", 
            bg="#282a36", 
            fg="#888888",
            font=("Courier New", 9),
            anchor="w"
        )
        self.uptime_label.pack(side="left", padx=10)
        
        # Правая часть: статусы и кнопки
        right_frame = tk.Frame(status_frame, bg="#282a36")
        right_frame.pack(side="right")
        
        # Статус оверлея
        self.overlay_status_label = tk.Label(
            right_frame, 
            text="Оверлей: Выкл (F8)", 
            bg="#282a36", 
            fg="#ff5555",
            font=("Courier New", 9),
            cursor="hand2"
        )
        self.overlay_status_label.pack(side="right", padx=10)
        self.overlay_status_label.bind("<Button-1>", lambda e: self.toggle_overlay())
        
        # Кнопка обновления
        refresh_btn = tk.Label(
            right_frame, 
            text="🔄 Обновить (F5)", 
            bg="#282a36", 
            fg="#55aaff",
            font=("Courier New", 9),
            cursor="hand2"
        )
        refresh_btn.pack(side="right", padx=10)
        refresh_btn.bind("<Button-1>", lambda e: self.force_refresh())
    
    def create_menu(self):
        """Создание простого меню"""
        menu_frame = tk.Frame(self.root, bg="#282a36", height=30)
        menu_frame.pack(fill="x", side="top", padx=10, pady=(10, 0))
        menu_frame.pack_propagate(False)
        
        # Логотип/название
        title_label = tk.Label(
            menu_frame, 
            text="⚡ SYSTEM MONITOR", 
            bg="#282a36", 
            fg="#ff79c6",
            font=("Courier New", 12, "bold")
        )
        title_label.pack(side="left", padx=10)
        
        # Кнопки меню
        menu_buttons = [
            ("📊 Монитор", lambda: self.notebook.select(0)),
            ("📈 Графики", lambda: self.notebook.select(1)),
            ("🔍 Процессы", lambda: self.notebook.select(2)),
            ("📋 Логи", lambda: self.notebook.select(3)),
            ("❓ Справка", self.show_help),
            ("⛌ Выход", self.on_closing)
        ]
        
        for text, command in menu_buttons:
            btn = tk.Label(
                menu_frame, 
                text=text, 
                bg="#282a36", 
                fg="#f8f8f2",
                font=("Courier New", 10),
                cursor="hand2",
                padx=10
            )
            btn.pack(side="left", padx=5)
            btn.bind("<Button-1>", lambda e, cmd=command: cmd())
    
    def start_updates(self):
        """Запуск всех циклов обновления"""
        # Запускаем обновление времени
        self.update_time()
        
        # Запускаем обновление данных системы
        self.update_data()
        
        # Периодическая проверка состояния
        self.root.after(30000, self.check_system_health)  # Каждые 30 секунд
    
    def update_time(self):
        """Обновление времени в статус-баре"""
        if not self.running:
            return
            
        try:
            # Текущее время
            current_time = time.strftime("%H:%M:%S")
            self.update_time_label.config(text=f"Обновлено: {current_time}")
            
            # Время работы системы
            boot_time = psutil.boot_time()
            uptime_seconds = time.time() - boot_time
            
            days = int(uptime_seconds // 86400)
            hours = int((uptime_seconds % 86400) // 3600)
            minutes = int((uptime_seconds % 3600) // 60)
            seconds = int(uptime_seconds % 60)
            
            if days > 0:
                uptime_str = f"{days}д {hours:02d}:{minutes:02d}:{seconds:02d}"
            else:
                uptime_str = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
            
            self.uptime_label.config(text=f"Время работы: {uptime_str}")
            
        except Exception as e:
            self.uptime_label.config(text="Время работы: Ошибка")
        
        # Планируем следующее обновление через 1 секунду
        if self.running:
            self.root.after(1000, self.update_time)
    
    def update_data(self):
        """Обновление данных системы"""
        if not self.running:
            return
            
        try:
            # Обновляем данные в компонентах
            self.components.update_card_data_from_main_thread()
            
            # Обновляем список процессов
            self.components.update_processes_list()
            
            # Периодически обновляем статус
            if int(time.time()) % 10 == 0:  # Каждые 10 секунд
                self.update_system_status()
                
        except Exception as e:
            print(f"Ошибка обновления данных: {e}")
        
        # Планируем следующее обновление через 2 секунды
        if self.running:
            self.root.after(2000, self.update_data)
    
    def update_system_status(self):
        """Обновление статуса системы"""
        try:
            # Проверка критических параметров
            cpu_percent = psutil.cpu_percent(interval=0.1)
            ram = psutil.virtual_memory()
            
            if cpu_percent > 90:
                self.add_status_message(f"⚠️  Высокая загрузка CPU: {cpu_percent:.1f}%", "warning")
            if ram.percent > 90:
                self.add_status_message(f"⚠️  Высокое использование RAM: {ram.percent:.1f}%", "warning")
                
        except Exception:
            pass
    
    def add_status_message(self, message, msg_type="info"):
        """Добавление сообщения в статус"""
        self.status_messages.append({
            'time': time.strftime("%H:%M:%S"),
            'message': message,
            'type': msg_type
        })
        
        # Ограничиваем количество сообщений
        if len(self.status_messages) > 50:
            self.status_messages = self.status_messages[-50:]
    
    def check_system_health(self):
        """Проверка здоровья системы"""
        if not self.running:
            return
            
        try:
            # Проверка наличия критических процессов
            critical_processes = ['csrss.exe', 'winlogon.exe', 'services.exe']
            for proc in psutil.process_iter(['name']):
                if proc.info['name'].lower() in [p.lower() for p in critical_processes]:
                    break
            else:
                self.add_status_message("⚠️  Не обнаружены критические процессы", "warning")
                
        except Exception:
            pass
        
        # Планируем следующую проверку
        if self.running:
            self.root.after(30000, self.check_system_health)
    
    def setup_hotkeys(self):
        """Настройка горячих клавиш"""
        # Основные горячие клавиши
        self.root.bind("<F1>", lambda e: self.show_help())
        self.root.bind("<F5>", lambda e: self.force_refresh())
        self.root.bind("<F8>", lambda e: self.toggle_overlay())
        self.root.bind("<F11>", lambda e: self.toggle_fullscreen())
        
        # Комбинации клавиш
        self.root.bind("<Control-q>", lambda e: self.on_closing())
        self.root.bind("<Control-r>", lambda e: self.force_refresh())
        self.root.bind("<Control-o>", lambda e: self.toggle_overlay())
        self.root.bind("<Control-h>", lambda e: self.show_help())
        
        # Клавиши навигации
        self.root.bind("<Escape>", lambda e: self.on_closing())
        self.root.bind("<Alt-F4>", lambda e: self.on_closing())
        
        # Переключение вкладок
        self.root.bind("<Control-1>", lambda e: self.notebook.select(0))
        self.root.bind("<Control-2>", lambda e: self.notebook.select(1))
        self.root.bind("<Control-3>", lambda e: self.notebook.select(2))
        self.root.bind("<Control-4>", lambda e: self.notebook.select(3))
    
    def toggle_fullscreen(self):
        """Переключение полноэкранного режима"""
        self.is_fullscreen = not self.is_fullscreen
        self.root.attributes("-fullscreen", self.is_fullscreen)
        
        if not self.is_fullscreen:
            self.root.geometry("1200x800")
            self.center_window()
    
    def toggle_overlay(self):
        """Переключение оверлея"""
        try:
            if not self.overlay:
                self.overlay = PixelOverlay(self.root, self.components)
                self.overlay_status_label.config(
                    text="Оверлей: Вкл (F8)", 
                    fg="#00ff88"
                )
                self.add_status_message("✅ Оверлей активирован")
            else:
                if self.overlay.is_visible():
                    self.overlay.hide()
                    self.overlay_status_label.config(
                        text="Оверлей: Выкл (F8)", 
                        fg="#ff5555"
                    )
                    self.add_status_message("ℹ️  Оверлей скрыт")
                else:
                    self.overlay.show()
                    self.overlay_status_label.config(
                        text="Оверлей: Вкл (F8)", 
                        fg="#00ff88"
                    )
                    self.add_status_message("ℹ️  Оверлей показан")
        except Exception as e:
            print(f"Ошибка переключения оверлея: {e}")
            self.overlay_status_label.config(
                text="Оверлей: Ошибка", 
                fg="#ff5555"
            )
    
    def force_refresh(self):
        """Принудительное обновление всех данных"""
        try:
            # Обновляем компоненты
            self.components.force_refresh()
            
            # Обновляем процессы
            self.components.update_processes_list()
            
            # Обновляем оверлей если активен
            if self.overlay and self.overlay.is_visible():
                self.overlay.update_data()
            
            # Обновляем время в статусе
            current_time = time.strftime("%H:%M:%S")
            self.update_time_label.config(text=f"Обновлено: {current_time}")
            
            self.add_status_message("🔄 Данные обновлены вручную")
            
        except Exception as e:
            print(f"Ошибка принудительного обновления: {e}")
            self.add_status_message("❌ Ошибка обновления данных", "error")
    
    def show_help(self):
        """Показать справку"""
        help_text = """📋 SYSTEM MONITOR v1.0
----------------------------
Горячие клавиши:
• F1 - Эта справка
• F5 - Принудительное обновление
• F8 - Показать/скрыть оверлей
• F11 - Полноэкранный режим
• Ctrl+1-4 - Переключение вкладок
• Ctrl+Q или ESC - Выход

📊 Возможности:
• Мониторинг CPU/GPU/RAM
• Графики загрузки в реальном времени
• Список процессов с сортировкой
• Оверлей с ключевыми метриками
• Мониторинг температуры
• Ping до серверов
• Информация о батарее

🎮 Особенности:
• Автономная работа (не требует OHM)
• Адаптивный интерфейс
• Низкое потребление ресурсов
• Поддержка Windows 7/8/10/11

⚠️  Примечание:
Температуры доступны через системные датчики.
Для GPU требуется установленный драйвер NVIDIA/AMD.
FPS мониторинг работает с большинством игр.
"""
        
        # Создаем окно справки
        help_window = tk.Toplevel(self.root)
        help_window.title("Справка")
        help_window.geometry("500x600")
        help_window.configure(bg="#282a36")
        help_window.resizable(False, False)
        
        # Центрируем окно справки
        help_window.update_idletasks()
        width = 500
        height = 600
        x = (self.root.winfo_x() + self.root.winfo_width() // 2) - (width // 2)
        y = (self.root.winfo_y() + self.root.winfo_height() // 2) - (height // 2)
        help_window.geometry(f'{width}x{height}+{x}+{y}')
        
        # Текст справки
        text_frame = tk.Frame(help_window, bg="#282a36")
        text_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        help_text_widget = tk.Text(
            text_frame,
            bg="#282a36",
            fg="#f8f8f2",
            font=("Courier New", 10),
            wrap="word",
            relief="flat",
            borderwidth=0,
            highlightthickness=0,
            spacing1=2,
            spacing2=1,
            spacing3=2
        )
        help_text_widget.pack(fill="both", expand=True)
        
        help_text_widget.insert("1.0", help_text)
        help_text_widget.config(state="disabled")
        
        # Кнопка закрытия
        close_btn = tk.Button(
            help_window,
            text="Закрыть",
            command=help_window.destroy,
            bg="#44475a",
            fg="#f8f8f2",
            font=("Courier New", 11),
            relief="raised",
            bd=1,
            padx=20,
            pady=5
        )
        close_btn.pack(pady=(0, 20))
        
        help_window.transient(self.root)
        help_window.grab_set()
        help_window.focus_set()
    
    def on_closing(self):
        """Обработка закрытия приложения"""
        if not self.running:
            return
            
        self.running = False
        
        # Добавляем сообщение о закрытии
        self.add_status_message("🛑 Завершение работы...")
        
        try:
            # Останавливаем оверлей
            if self.overlay:
                self.overlay.destroy()
            
            # Останавливаем менеджер графиков
            if self.graph_manager:
                self.graph_manager.stop()
            
            # Останавливаем FPS монитор
            try:
                fps_monitor = get_fps_monitor()
                fps_monitor.stop()
            except Exception:
                pass
            
            # Небольшая задержка для завершения операций
            self.root.after(100, self.root.destroy)
            
        except Exception as e:
            print(f"Ошибка при закрытии: {e}")
            self.root.destroy()
    
    def run(self):
        """Запуск главного цикла приложения"""
        try:
            # Финальная инициализация
            self.add_status_message("🚀 Приложение запущено")
            
            # Запускаем главный цикл
            self.root.mainloop()
            
        except Exception as e:
            print(f"Критическая ошибка: {e}")
            # Попытка корректного завершения
            try:
                self.on_closing()
            except:
                pass

def main():
    """Главная функция приложения"""
    print("=" * 50)
    print("SYSTEM MONITOR v1.0")
    print("Автономный мониторинг системы")
    print("=" * 50)
    
    try:
        # Проверка операционной системы
        import platform
        system = platform.system()
        print(f"ОС: {system}")
        
        if system != "Windows":
            print("⚠️  Приложение оптимизировано для Windows")
            print("Некоторые функции могут работать некорректно")
        
        # Создание и запуск приложения
        app = SystemMonitor()
        app.run()
        
        print("✅ Приложение завершено корректно")
        
    except ImportError as e:
        print(f"❌ Ошибка импорта: {e}")
        print("Установите необходимые зависимости:")
        print("pip install psutil GPUtil pywin32")
        input("Нажмите Enter для выхода...")
        
    except Exception as e:
        print(f"❌ Непредвиденная ошибка: {e}")
        input("Нажмите Enter для выхода...")

if __name__ == "__main__":
    main()